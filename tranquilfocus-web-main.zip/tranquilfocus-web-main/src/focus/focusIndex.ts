/**
 * Focus Index computation and smoothing
 * Calculates a 0-1 focus score based on sensor inputs
 */

import { clamp, variance } from '../utils/math';
import type { SensorData } from './sensors';

/**
 * Normalize variance to [0,1] range
 */
function normalizeVariance(varianceMs2: number, maxVarianceMs2: number = 400): number {
  return clamp(varianceMs2 / maxVarianceMs2, 0, 1);
}

/**
 * Calculate typing stability from IKI array
 * Returns 1 for stable typing (low variance), 0 for erratic typing
 */
export function calculateTypingStability(ikiMsArray: number[]): number {
  if (ikiMsArray.length < 2) return 0;
  
  const ikiVariance = variance(ikiMsArray);
  const normalizedVariance = normalizeVariance(ikiVariance, 400);
  const stability = 1 - normalizedVariance;
  
  return clamp(stability, 0, 1);
}

/**
 * Calculate mouse jitter score
 * Higher frequency = more distraction
 */
export function calculateMouseJitter(mouseHz: number): number {
  return clamp(mouseHz / 10, 0, 1);
}

/**
 * Calculate dwell score
 * Longer dwell time = more focus (caps at 3 minutes)
 */
export function calculateDwellScore(dwellSec: number): number {
  return clamp(dwellSec / 180, 0, 1);
}

/**
 * Calculate idle score
 * Time since last input indicates inactivity
 */
export function calculateIdleScore(lastInputAt: number, now: number): number {
  if (lastInputAt === 0) return 1; // No input yet
  
  const timeSinceInput = now - lastInputAt;
  return clamp(timeSinceInput / 5000, 0, 1);
}

/**
 * Calculate Focus Index from sensor data
 * Formula: focus = 0.4 * typing + 0.35 * dwell - 0.15 * jitter - 0.10 * idle
 */
export function calculateFocusIndex(sensorData: SensorData): number {
  const now = Date.now();
  
  const typingStability = calculateTypingStability(sensorData.ikiMsArray);
  const dwell = calculateDwellScore(sensorData.dwellSec);
  const mouseJitter = calculateMouseJitter(sensorData.mouseHz);
  const idle = calculateIdleScore(sensorData.lastInputAt, now);
  
  const focus = 
    0.4 * typingStability +
    0.35 * dwell -
    0.15 * mouseJitter -
    0.10 * idle;
  
  return clamp(focus, 0, 1);
}

/**
 * Attack/Release smoother for natural focus transitions
 * Fast rise (attack), slow fall (release)
 */
export class AttackReleaseSmoother {
  private lastValue: number = 0;
  private lastUpdateTime: number = 0;
  
  constructor(
    private attackTimeMs: number = 300,
    private releaseTimeMs: number = 1500
  ) {}

  /**
   * Apply smoothing to a new value
   */
  smooth(newValue: number, now: number = Date.now()): number {
    if (this.lastUpdateTime === 0) {
      this.lastValue = newValue;
      this.lastUpdateTime = now;
      return newValue;
    }
    
    const deltaTime = now - this.lastUpdateTime;
    const isRising = newValue > this.lastValue;
    
    // Choose time constant based on attack/release
    const timeConstant = isRising ? this.attackTimeMs : this.releaseTimeMs;
    
    // Exponential smoothing: α = 1 - e^(-Δt / τ)
    const alpha = 1 - Math.exp(-deltaTime / timeConstant);
    
    // Apply EMA
    const smoothedValue = this.lastValue + alpha * (newValue - this.lastValue);
    
    this.lastValue = smoothedValue;
    this.lastUpdateTime = now;
    
    return smoothedValue;
  }

  /**
   * Get current value without updating
   */
  getValue(): number {
    return this.lastValue;
  }

  /**
   * Reset the smoother
   */
  reset(): void {
    this.lastValue = 0;
    this.lastUpdateTime = 0;
  }
}

