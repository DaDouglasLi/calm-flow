# Focus Index Algorithm - TranquilFocus

## Overview

The Focus Index is a real-time score (0.0 - 1.0) that quantifies user engagement and concentration based on behavioral sensors. The algorithm uses a multi-factor weighted formula with attack/release smoothing for natural transitions.

## Algorithm Version

**Branch:** `feat/focus-core`  
**Version:** 2.0  
**Date:** 2024

## Input Sensors

All inputs are normalized to the range [0, 1]:

### 1. Typing Stability (`typingStability`)

**Source:** Inter-keystroke interval (IKI) variance

**Formula:**
```
variance = Σ(IKI_i - mean(IKI))² / n
normalizedVariance = clamp(variance / 400ms², 0, 1)
typingStability = 1 - normalizedVariance
```

**Interpretation:**
- **1.0** = Very stable, rhythmic typing (low variance)
- **0.5** = Moderate variation in typing rhythm
- **0.0** = Erratic typing (high variance > 400ms²)

**Why it matters:** Stable typing rhythm indicates focused, deliberate work. Erratic typing suggests distraction or task switching.

### 2. Mouse Jitter (`mouseJitter`)

**Source:** Mouse movement frequency (Hz)

**Formula:**
```
mouseJitter = clamp(mouseHz / 10, 0, 1)
```

**Interpretation:**
- **0.0** = No mouse movement
- **0.3** = Moderate activity (~3 Hz)
- **1.0** = Very high activity (≥10 Hz)

**Why it matters:** Excessive mouse movement often correlates with distraction, searching, or anxiety. Moderate movement is normal for engaged work.

### 3. Dwell Score (`dwell`)

**Source:** Continuous time on current page

**Formula:**
```
dwell = clamp(dwellSec / 180, 0, 1)
```

**Interpretation:**
- **0.0** = Just arrived on page
- **0.5** = 90 seconds on page
- **1.0** = 3+ minutes on page (capped)

**Why it matters:** Sustained attention on a single page indicates deep work. Frequent tab switching suggests distraction.

### 4. Idle Score (`idle`)

**Source:** Time since last input event

**Formula:**
```
idle = clamp((now - lastInputAt) / 5000ms, 0, 1)
```

**Interpretation:**
- **0.0** = Active input right now
- **0.5** = 2.5 seconds since last input
- **1.0** = 5+ seconds idle (capped)

**Why it matters:** Extended idle time suggests the user has stepped away or is passively consuming content (lower focus).

## Focus Index Calculation

### Core Formula

```javascript
focus = 0.4 * typingStability 
      + 0.35 * dwell 
      - 0.15 * mouseJitter 
      - 0.10 * idle

focus = clamp(focus, 0, 1)
```

### Weight Justification

| Factor | Weight | Direction | Reasoning |
|--------|--------|-----------|-----------|
| Typing Stability | **40%** | Positive | Strongest signal of cognitive engagement |
| Dwell Time | **35%** | Positive | Sustained attention is key to focus |
| Mouse Jitter | **15%** | Negative | Excessive movement indicates distraction |
| Idle Time | **10%** | Negative | Inactivity suggests disengagement |

**Total:** 40% + 35% - 15% - 10% = **50% baseline**

This means:
- Perfect conditions (all factors optimal): **focus = 1.0**
- Neutral conditions: **focus ≈ 0.5**
- Poor conditions: **focus ≈ 0.0**

## Attack/Release Smoothing

Raw focus values are smoothed using an asymmetric exponential moving average to create natural transitions.

### Parameters

- **Attack Time (τ_attack):** 300ms - Fast response to increasing focus
- **Release Time (τ_release):** 1500ms - Slow decay when focus drops

### Formula

```javascript
deltaTime = currentTime - lastUpdateTime
isRising = newValue > currentValue

τ = isRising ? τ_attack : τ_release

α = 1 - e^(-Δt / τ)

smoothedValue = currentValue + α * (newValue - currentValue)
```

### Effect

```
Raw Focus:    0.2 ──────┐              ┌─── 0.8
                         │              │
                         └──────────────┘
                         
Smoothed:     0.2 ────────╱────────╲____ 0.8
                        fast      slow
                       (300ms)  (1500ms)
```

**Rationale:**
- **Fast attack:** Reward focused behavior immediately
- **Slow release:** Don't penalize brief pauses or micro-breaks
- **Human-like:** Mimics how we perceive our own focus state

## Example Calculations

### Scenario 1: Deep Focused Work

```
Inputs:
- typingStability = 0.85 (steady rhythm)
- dwell = 1.0 (been here 3+ minutes)
- mouseJitter = 0.2 (minimal movement)
- idle = 0.1 (active within 500ms)

Calculation:
focus = 0.4(0.85) + 0.35(1.0) - 0.15(0.2) - 0.10(0.1)
      = 0.34 + 0.35 - 0.03 - 0.01
      = 0.65

Result: High focus (0.65)
```

### Scenario 2: Distracted Browsing

```
Inputs:
- typingStability = 0.2 (no typing or erratic)
- dwell = 0.1 (just arrived, 18 seconds)
- mouseJitter = 0.7 (lots of scrolling/clicking)
- idle = 0.4 (2 seconds since last input)

Calculation:
focus = 0.4(0.2) + 0.35(0.1) - 0.15(0.7) - 0.10(0.4)
      = 0.08 + 0.035 - 0.105 - 0.04
      = -0.03 → 0.0 (clamped)

Result: Very low focus (0.0)
```

### Scenario 3: Reading/Research

```
Inputs:
- typingStability = 0.0 (no typing)
- dwell = 0.8 (2.4 minutes on page)
- mouseJitter = 0.3 (occasional scrolling)
- idle = 0.8 (4 seconds idle, reading)

Calculation:
focus = 0.4(0.0) + 0.35(0.8) - 0.15(0.3) - 0.10(0.8)
      = 0.0 + 0.28 - 0.045 - 0.08
      = 0.155

Result: Moderate focus (0.16)
```

## Temporal Dynamics

```
Time (s)   0    10   20   30   40   50   60   70   80   90
           │    │    │    │    │    │    │    │    │    │
Typing     ████████████████                    ████████████
Dwell      ▁▁▂▂▃▃▄▄▅▅▆▆▇▇███████████████████████████████
Mouse      ▃▃▄▄▃▃▂▂▁▁▁▁▁▁▁▁▁▁▂▂▃▃▄▄▅▅▆▆▇▇████████▇▇▆▆▅▅
Idle       ▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁████████████████▁▁▁▁▁▁▁▁
           │    │    │    │    │    │    │    │    │    │
Focus      ▃▃▅▅▆▆▇▇███▇▇▅▅▄▄▃▃▃▃▃▃▄▄▅▅▇▇▇▇▆▆▅▅▄▄▃▃▂▂
```

## Edge Cases

### Page Not Visible

```javascript
if (!sensorData.visible) {
  return 0; // Instant drop to 0
}
```

**Rationale:** If the tab isn't visible, user is definitely not focused on it.

### Insufficient Data

```javascript
if (ikiMsArray.length < 2) {
  typingStability = 0; // Not enough data
}
```

**Rationale:** Need multiple keystrokes to calculate variance meaningfully.

### No Input Yet

```javascript
if (lastInputAt === 0) {
  idle = 1; // Fully idle
}
```

**Rationale:** Before first interaction, user hasn't engaged.

## Performance Characteristics

- **Update Frequency:** Every 1 second (1 Hz)
- **Computational Complexity:** O(n) where n = IKI array size (max 50)
- **Memory Footprint:** ~1KB per tab (sensor data + history)
- **Latency:** <5ms per calculation

## Calibration & Tuning

The algorithm can be tuned by adjusting:

### Sensor Normalization Ranges

```javascript
// In src/background/focus.js
const MAX_IKI_VARIANCE = 400;  // ms²
const MAX_MOUSE_HZ = 10;       // Hz
const MAX_DWELL_SEC = 180;     // seconds
const MAX_IDLE_MS = 5000;      // milliseconds
```

### Weights

```javascript
const WEIGHTS = {
  typingStability: 0.4,
  dwell: 0.35,
  mouseJitter: -0.15,
  idle: -0.10
};
```

### Smoothing Time Constants

```javascript
const ATTACK_TIME_MS = 300;
const RELEASE_TIME_MS = 1500;
```

## Validation Approaches

1. **Self-report correlation:** Compare with user's subjective focus ratings
2. **Task performance:** Correlate with productivity metrics (words written, code commits)
3. **Attention switching:** Count tab switches during "focused" vs "unfocused" periods
4. **Session quality:** User satisfaction surveys post-session

## Future Improvements

- [ ] Adaptive weights based on user's work style
- [ ] Context awareness (coding vs. writing vs. reading)
- [ ] Time-of-day calibration
- [ ] Machine learning for personalized thresholds
- [ ] Multi-window focus tracking
- [ ] Break detection and recommendation

## References

- Keystroke dynamics research (IKI variance as cognitive load indicator)
- Flow state theory (Csikszentmihalyi)
- Attention restoration theory
- HCI research on focus and distraction

---

**Last Updated:** 2024  
**Authors:** TranquilFocus Team  
**Branch:** feat/focus-core

