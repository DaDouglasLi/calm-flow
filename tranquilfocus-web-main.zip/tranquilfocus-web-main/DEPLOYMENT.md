# 🚀 Deployment Guide

Complete guide to deploying TranquilFocus to various platforms.

## Prerequisites

```bash
npm install
npm run build
```

This creates an optimized production build in the `dist/` folder.

---

## Vercel (Easiest - Recommended)

### Option 1: Vercel CLI

```bash
# Install Vercel CLI globally
npm i -g vercel

# Deploy (follow prompts)
vercel

# Deploy to production
vercel --prod
```

### Option 2: Vercel Dashboard

1. Visit [vercel.com/new](https://vercel.com/new)
2. Import your Git repository (GitHub/GitLab/Bitbucket)
3. Configure:
   - **Framework Preset:** Vite
   - **Build Command:** `npm run build`
   - **Output Directory:** `dist`
   - **Install Command:** `npm install`
4. Click **Deploy**

**Environment Variables:** None needed!

**Custom Domain:** Add in Project Settings → Domains

---

## Netlify

### Option 1: Drag & Drop

1. Run `npm run build`
2. Visit [app.netlify.com/drop](https://app.netlify.com/drop)
3. Drag the `dist/` folder onto the page
4. Done! Your site is live

### Option 2: Netlify CLI

```bash
# Install Netlify CLI
npm i -g netlify-cli

# Build
npm run build

# Deploy
netlify deploy

# Deploy to production
netlify deploy --prod
```

### Option 3: Git Integration

1. Push your code to GitHub/GitLab/Bitbucket
2. Visit [app.netlify.com](https://app.netlify.com)
3. Click **New site from Git**
4. Configure:
   - **Build Command:** `npm run build`
   - **Publish Directory:** `dist`
5. Click **Deploy site**

**netlify.toml** (optional):
```toml
[build]
  command = "npm run build"
  publish = "dist"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
```

---

## GitHub Pages

```bash
# Build the project
npm run build

# Navigate to build output
cd dist

# Initialize git (if not already)
git init
git add -A
git commit -m 'Deploy to GitHub Pages'

# Force push to gh-pages branch
git push -f git@github.com:USERNAME/REPO.git main:gh-pages

# Go back to project root
cd ..
```

**Or use gh-pages package:**

```bash
npm install --save-dev gh-pages

# Add to package.json scripts:
"deploy": "npm run build && gh-pages -d dist"

# Deploy
npm run deploy
```

**Enable GitHub Pages:**
1. Go to repository Settings → Pages
2. Source: Deploy from branch `gh-pages`
3. Folder: `/ (root)`
4. Save

Your site will be at: `https://username.github.io/repo-name/`

---

## Cloudflare Pages

### Option 1: Wrangler CLI

```bash
# Install Wrangler
npm i -g wrangler

# Build
npm run build

# Deploy
wrangler pages publish dist
```

### Option 2: Dashboard

1. Visit [dash.cloudflare.com](https://dash.cloudflare.com)
2. Go to **Pages** → **Create a project**
3. Connect your Git repository
4. Configure:
   - **Build command:** `npm run build`
   - **Build output directory:** `dist`
5. Click **Save and Deploy**

**Fast global CDN + automatic HTTPS!**

---

## AWS S3 + CloudFront

```bash
# Install AWS CLI
# https://aws.amazon.com/cli/

# Build
npm run build

# Create S3 bucket
aws s3 mb s3://tranquilfocus-app

# Upload files
aws s3 sync dist/ s3://tranquilfocus-app --delete

# Make public (bucket policy)
# Enable static website hosting in S3 console
# Optional: Add CloudFront distribution for CDN
```

**Bucket Policy Example:**
```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Sid": "PublicReadGetObject",
    "Effect": "Allow",
    "Principal": "*",
    "Action": "s3:GetObject",
    "Resource": "arn:aws:s3:::tranquilfocus-app/*"
  }]
}
```

---

## DigitalOcean App Platform

1. Visit [cloud.digitalocean.com/apps](https://cloud.digitalocean.com/apps)
2. Click **Create App**
3. Connect your Git repository
4. Configure:
   - **Type:** Static Site
   - **Build Command:** `npm run build`
   - **Output Directory:** `dist`
5. Choose plan (Static sites are free!)
6. Launch

---

## Surge.sh (Quick Testing)

```bash
# Install Surge
npm i -g surge

# Build
npm run build

# Deploy
cd dist
surge

# Custom domain
surge --domain tranquilfocus.surge.sh
```

---

## Railway

```bash
# Install Railway CLI
npm i -g @railway/cli

# Login
railway login

# Initialize
railway init

# Deploy
railway up
```

Or connect via Railway dashboard with Git integration.

---

## Render

1. Visit [render.com](https://render.com)
2. New **Static Site**
3. Connect your Git repository
4. Configure:
   - **Build Command:** `npm run build`
   - **Publish Directory:** `dist`
5. Deploy

Free tier available with auto-deployments on Git push!

---

## Firebase Hosting

```bash
# Install Firebase CLI
npm i -g firebase-tools

# Login
firebase login

# Initialize
firebase init hosting

# Configure:
# - Public directory: dist
# - Single-page app: Yes
# - GitHub auto-deploys: Optional

# Build
npm run build

# Deploy
firebase deploy --only hosting
```

---

## Custom Server (VPS/Dedicated)

If you have a server with Nginx/Apache:

```bash
# Build locally
npm run build

# Upload dist/ folder to server
scp -r dist/* user@server:/var/www/tranquilfocus/

# Nginx config example:
server {
    listen 80;
    server_name tranquilfocus.com;
    root /var/www/tranquilfocus;
    index index.html;
    
    location / {
        try_files $uri $uri/ /index.html;
    }
    
    # Cache static assets
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

---

## Performance Tips

### After Deployment

1. **Test with Lighthouse:**
   - Open DevTools → Lighthouse
   - Run audit
   - Aim for 90+ scores

2. **Enable Compression:**
   - Most platforms auto-enable Gzip/Brotli
   - Verify with: `curl -H "Accept-Encoding: gzip" -I https://yoursite.com`

3. **CDN Configuration:**
   - Set cache headers
   - Enable HTTP/2 or HTTP/3
   - Use edge caching

4. **Monitor Performance:**
   - Set up [web-vitals](https://github.com/GoogleChrome/web-vitals)
   - Track Core Web Vitals

---

## Custom Domains

Most platforms support custom domains:

1. **Buy domain** (Namecheap, Google Domains, Cloudflare, etc.)
2. **Add DNS records:**
   - A record → Platform's IP
   - Or CNAME → Platform's domain
3. **Enable HTTPS** (usually automatic with Let's Encrypt)

**Example (Vercel):**
- Add domain in project settings
- Add DNS: `CNAME → cname.vercel-dns.com`
- Wait for SSL certificate (automatic)

---

## Troubleshooting

### Build fails
```bash
# Clear cache
rm -rf node_modules dist
npm install
npm run build
```

### Blank page after deploy
- Check browser console for errors
- Verify base path in vite.config.js
- Check file paths (case-sensitive on Linux servers)

### Assets not loading
- Ensure paths are relative or absolute
- Check `public/` folder files are included
- Verify CORS if loading external resources

---

## Next Steps

- 🔒 Add HTTPS (usually automatic)
- 📊 Set up analytics (optional)
- 🌍 Configure CDN for global performance
- 🔄 Enable automatic deploys on Git push
- 📱 Test on mobile devices
- ⚡ Monitor performance metrics

---

**Questions?** Open an issue or check platform-specific docs!

