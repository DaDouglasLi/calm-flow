# ⚡ Quick Start Guide

Get TranquilFocus running in 60 seconds!

## 🏃 Steps

### 1️⃣ Navigate to Project

```bash
cd tranquilfocus-web
```

### 2️⃣ Install Dependencies

```bash
npm install
```

This installs:
- `typescript` - Type checking
- `vite` - Lightning-fast dev server & build

**Install time:** ~10 seconds

### 3️⃣ Start Development Server

```bash
npm run dev
```

**Expected output:**
```
  VITE v5.0.10  ready in 234 ms

  ➜  Local:   http://localhost:3000/
  ➜  Network: use --host to expose
```

### 4️⃣ Open in Browser

Your browser should open automatically to `http://localhost:3000`

If not, click the link in the terminal.

---

## 🎮 Using the App

### First Load

You'll see:
- **Left Panel:** Controls (start button, theme toggles, sliders)
- **Right Panel:** Animated canvas (particles flowing)
- **Top Right:** Small colored band (focus indicator)

### Start Tracking

**Option 1:** Click the **Start** button

**Option 2:** Just start typing or moving your mouse!
- The app auto-starts on first input

### Watch the Magic ✨

1. **Type something** → Focus Index increases
2. **Move mouse rapidly** → Index decreases (jitter)
3. **Stay idle 5+ seconds** → Index drops (idle)
4. **Type steadily** → Index rises to ~0.7-0.9 (Tranquil!)

### Adjust Settings

**Theme:**
- Click **Day** for light mode
- Click **Night** for dark mode

**Intensity:**
- Drag slider left (0%) for minimal particles
- Drag slider right (100%) for maximum visual

**Session:**
- Click **Stop** to pause tracking
- Click **Start** to resume

---

## 🎯 What to Look For

### Focus States

🔵 **Tranquil (0.7-1.0)**
- Calm blue colors
- Slow, peaceful particle movement
- You're in the zone!

💜 **Balanced (0.4-0.7)**
- Violet/purple tones
- Moderate motion
- Good focus level

🟠 **Scattered (0.0-0.4)**
- Warm orange colors
- Faster, more chaotic motion
- Distracted state

### Visual Feedback

**Particles:**
- Speed changes with focus (high focus = slow & calm)
- Color shifts smoothly between states
- Background gradient evolves

**Overlay Band (Top Right):**
- Color matches focus state
- Tooltip shows exact focus value
- Hover to expand slightly

**Control Panel (Left):**
- Large focus value display
- State label (Tranquil/Balanced/Scattered)
- Progress bar fills based on focus

---

## 🛠️ Commands Cheat Sheet

```bash
# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Type checking only (no run)
npm run type-check
```

---

## 🚀 Deploy to Vercel (60 seconds)

```bash
# Install Vercel CLI
npm i -g vercel

# Build
npm run build

# Deploy (follow prompts)
vercel

# Done! Your app is live at https://your-app.vercel.app
```

For other platforms, see **DEPLOYMENT.md**

---

## 🐛 Troubleshooting

### Port 3000 already in use

```bash
# Kill existing process on port 3000
# Windows:
netstat -ano | findstr :3000
taskkill /PID <PID> /F

# Or change port in vite.config.js:
server: { port: 3001 }
```

### Blank screen after start

1. Open browser DevTools (F12)
2. Check Console for errors
3. Refresh page (Ctrl+R or Cmd+R)
4. Clear cache and hard reload (Ctrl+Shift+R)

### Canvas not showing particles

- Update your browser (Chrome 90+, Firefox 88+, Safari 14+)
- Enable hardware acceleration in browser settings
- Check console for WebGL errors

### TypeScript errors

```bash
# Delete and reinstall
rm -rf node_modules
npm install
```

---

## 📚 Learn More

- **README.md** - Full documentation
- **DEPLOYMENT.md** - Deployment to 10+ platforms
- **MIGRATION_GUIDE.md** - How extension became web app
- **PROJECT_SUMMARY.md** - Complete project overview

---

## ✅ Success Checklist

After running `npm run dev`, you should see:

- [x] Browser opens to localhost:3000
- [x] Split layout (controls left, canvas right)
- [x] Animated particles moving
- [x] Start button clickable
- [x] Typing/mouse moves particles
- [x] Focus index updates in real-time
- [x] No console errors

**If all checked, you're ready to go!** 🎉

---

## 💡 Pro Tips

1. **Keyboard Test:** Type a paragraph steadily to see focus rise to ~0.8+
2. **Mouse Test:** Move mouse randomly to see focus drop (jitter penalty)
3. **Idle Test:** Stop all input for 5+ seconds to see focus decay
4. **Theme Test:** Toggle Day/Night to see color palette changes
5. **Mobile Test:** Open on phone - it's fully responsive!

---

## 🎯 Next Steps

**For Development:**
- Edit files in `src/` and see changes live
- Customize colors in `src/visual/colors.ts`
- Tweak focus formula in `src/focus/focusIndex.ts`

**For Deployment:**
- Run `npm run build` to create production build
- Upload `dist/` folder to any static host
- See DEPLOYMENT.md for specific platform guides

**For Understanding:**
- Read MIGRATION_GUIDE.md to understand architecture
- Explore PROJECT_SUMMARY.md for comprehensive overview
- Check code comments for detailed explanations

---

**Happy focusing! 🧘✨**

