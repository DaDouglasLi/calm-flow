# TranquilFocus Sensor System

## Overview

The TranquilFocus sensor system tracks lightweight behavioral signals to calculate a real-time focus index (0.0 - 1.0). The system is designed to be non-intrusive and privacy-preserving, with all data processing happening locally in the browser.

## Sensor Types

### 1. Keyboard Cadence (IKI - Inter-Keystroke Intervals)

**What it tracks:** Time intervals (in milliseconds) between consecutive keystrokes

**Data structure:** Array of last 50 intervals (e.g., `[234, 456, 189, ...]`)

**Focus signals:**
- Steady typing rhythm (200-800ms avg) → High focus
- Very fast typing (<200ms avg) → Possible stress/urgency
- Thoughtful typing (800-2000ms avg) → Moderate focus
- Long pauses (>2000ms avg) → Low activity

**Implementation:**
```javascript
document.addEventListener('keydown', (event) => {
  const interval = now - lastKeystrokeTimestamp;
  ikiMsArray.push(interval);
  // Keep last 50 only
});
```

### 2. Mouse Jitter (Movement Frequency)

**What it tracks:** Mouse movement events per second, smoothed with EMA

**Data structure:** Single number representing Hz (e.g., `2.45`)

**Focus signals:**
- Moderate activity (1-5 Hz) → Engaged/focused
- Low activity (<1 Hz) → Passive consumption
- High activity (>5 Hz) → Possibly distracted or searching

**Implementation:**
```javascript
// EMA (Exponential Moving Average) calculation
mouseHz = α × currentHz + (1 - α) × previousMouseHz
// α = 0.3 (smoothing factor)
```

### 3. Page Visibility

**What it tracks:** Whether the current tab is visible and focused

**Data structure:** Boolean (`true` or `false`)

**Focus signals:**
- Visible = potential focus
- Hidden = definitely not focused on this page

**Implementation:**
```javascript
document.addEventListener('visibilitychange', () => {
  visible = !document.hidden;
});
```

### 4. Dwell Time (Active Window Continuity)

**What it tracks:** Seconds spent on the current page without switching tabs

**Data structure:** Number in seconds (e.g., `45.23`)

**Focus signals:**
- Longer dwell time → Higher sustained focus
- Resets on tab switch or navigation
- Only counts when page is visible

**Implementation:**
```javascript
// Reset on visibility change
dwellSec = (Date.now() - dwellStartTime) / 1000;
```

### 5. Last Input Timestamp

**What it tracks:** Timestamp of the most recent user interaction

**Data structure:** Unix timestamp in milliseconds

**Focus signals:**
- Recent activity (<5s ago) → Active engagement
- Stale activity (>5s ago) → Passive or away

## Data Flow

```
┌─────────────────────┐
│  User Interactions  │
│  (keys, mouse, etc) │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│  sensors.js         │
│  - Event listeners  │
│  - Data buffering   │
│  - EMA calculations │
└──────────┬──────────┘
           │ getData() called every 1s
           ▼
┌─────────────────────┐
│  content.js         │
│  - Sensor ticker    │
│  - Message sender   │
└──────────┬──────────┘
           │ SENSOR_TICK message
           ▼
┌─────────────────────┐
│  background.js      │
│  - Process sensors  │
│  - Calculate focus  │
│  - Update UI        │
└─────────────────────┘
```

## Focus Index Calculation

The focus index is calculated using a sophisticated multi-factor algorithm (v2.0):

```javascript
Focus Index = 0.4 × typingStability + 0.35 × dwell - 0.15 × mouseJitter - 0.10 × idle
```

**Inputs (all normalized to 0..1):**
- `typingStability` = 1 - variance(IKI) / 400ms²
- `mouseJitter` = mouseHz / 10
- `dwell` = dwellSec / 180
- `idle` = (now - lastInputAt) / 5000ms

See [`docs/FOCUS_ALGORITHM.md`](FOCUS_ALGORITHM.md) for complete details.

### Attack/Release Smoothing

The algorithm uses asymmetric exponential smoothing:

- **Attack (rising focus):** 300ms time constant - fast response
- **Release (falling focus):** 1500ms time constant - slow decay

```javascript
α = 1 - exp(-Δt / τ)
smoothed = previous + α × (new - previous)

where τ = isRising ? 300ms : 1500ms
```

This creates natural transitions that reward focus quickly but don't penalize brief pauses.

## Privacy & Performance

### Privacy
- **No data leaves the browser** - All processing is local
- **No network requests** - Sensors operate entirely offline
- **No PII collected** - Only behavioral patterns, no content
- **Ephemeral storage** - Only last 100 sensor ticks saved
- **User control** - Can disable via settings

### Performance
- **Passive listeners** - All event listeners use `{ passive: true }`
- **Throttled updates** - Sensor data sent only once per second
- **Small memory footprint** - IKI buffer limited to 50 items
- **EMA smoothing** - Reduces computation vs. full history
- **No DOM manipulation** - Sensors don't touch the page

## API Reference

### `startSensors()`

Initializes the sensor system and returns a stream interface.

**Returns:** `SensorStream` object

```javascript
const stream = window.TranquilFocusSensors.startSensors();
```

### `SensorStream.getData()`

Returns a snapshot of current sensor data.

**Returns:** `SensorData` object

```javascript
const data = stream.getData();
// {
//   ikiMsArray: [234, 456, 189, ...],
//   mouseHz: 2.45,
//   visible: true,
//   dwellSec: 45.23,
//   lastInputAt: 1698765432100
// }
```

### `SensorStream.destroy()`

Removes all event listeners and cleans up resources.

```javascript
stream.destroy();
```

## Message Protocol

### SENSOR_TICK Message

Sent from content.js to background.js every second.

```javascript
{
  type: 'SENSOR_TICK',
  payload: {
    ikiMsArray: number[],
    mouseHz: number,
    visible: boolean,
    dwellSec: number,
    lastInputAt: number
  },
  timestamp: number
}
```

## Customization

You can adjust the sensor parameters in `src/content/sensors.js`:

```javascript
const IKI_BUFFER_SIZE = 50;           // Number of keystrokes to track
const MOUSE_EMA_ALPHA = 0.3;          // Mouse smoothing (0-1)
const MOUSE_SAMPLE_WINDOW = 1000;     // Mouse Hz calculation window (ms)
```

And the focus calculation in `background.js`:

```javascript
// Adjust weights in calculateFocusFromSensors()
// Adjust thresholds for keyboard/mouse scoring
// Adjust EMA smoothing factor
```

## Future Enhancements

- [ ] Scroll velocity tracking
- [ ] Click pattern analysis
- [ ] Text selection monitoring
- [ ] Idle time detection
- [ ] Audio/video playback awareness
- [ ] Application context (work vs. social sites)
- [ ] Time-of-day adjustments
- [ ] Personal baseline calibration

