# Build & Deployment Guide - TranquilFocus

## Overview

This guide covers building, packaging, and deploying TranquilFocus for various distribution channels.

**Branch:** `docs/build-deliver`

---

## Quick Start

```bash
# Install dependencies
npm install

# Build for distribution
npm run build

# Create .zip for Chrome Web Store
npm run zip
```

**Output:** `dist/tranquilfocus-v0.6.0.zip`

---

## Development Mode

### No Build Step Required

TranquilFocus uses vanilla JavaScript - no bundler needed for development!

```bash
# Clone repo
git clone https://github.com/yourusername/tranquilfocus.git
cd tranquilfocus

# Load directly in Chrome
# 1. Open chrome://extensions/
# 2. Enable "Developer mode"
# 3. Click "Load unpacked"
# 4. Select the project root folder
```

### Hot Reload

Changes to files require extension reload:
- Go to `chrome://extensions/`
- Click the refresh icon on the extension card
- OR disable and re-enable

---

## Build Process

### Build Script (`scripts/build.js`)

Copies necessary files to `dist/` directory:

**Included:**
- `manifest.json`
- `background.js`, `content.js`
- `popup.html/js`, `options.html/js`
- `src/` (all modules)
- `styles/`
- `icons/`

**Excluded:**
- Documentation (`docs/`, `README.md`, etc.)
- Development files (`package.json`, `.git`)
- Build artifacts (`node_modules/`, `dist/`)
- Assets (`assets/`, screenshots)

**Run:**
```bash
npm run build
```

**Output:**
```
dist/
├── manifest.json
├── background.js
├── content.js
├── popup.html
├── popup.js
├── options.html
├── options.js
├── src/
├── styles/
└── icons/
```

---

## Packaging for Distribution

### Zip Creation (`scripts/zip.js`)

Creates a compressed .zip ready for Chrome Web Store:

```bash
npm run zip
```

**Process:**
1. Reads version from `dist/manifest.json`
2. Creates `tranquilfocus-v{version}.zip`
3. Compresses with maximum compression (level 9)
4. Outputs to `dist/`

**Example Output:**
```
📦 Creating tranquilfocus-v0.6.0.zip...

✅ Zip created successfully!
📂 File: dist/tranquilfocus-v0.6.0.zip
📊 Size: 45.32 KB

Ready for Chrome Web Store submission!
```

---

## Chrome Web Store Submission

### Prerequisites

- [Chrome Web Store Developer Account](https://chrome.google.com/webstore/devconsole) ($5 one-time fee)
- Built and zipped extension
- Store listing assets (screenshots, description)

### Steps

1. **Build and Package**
   ```bash
   npm run build
   npm run zip
   ```

2. **Prepare Assets**
   - Screenshots: 1280x800 or 640x400 (1-5 images)
   - Icon: 128x128 (already in `icons/icon128.png`)
   - Promotional images (optional):
     - Small: 440x280
     - Marquee: 1400x560

3. **Upload to Store**
   - Go to [Developer Dashboard](https://chrome.google.com/webstore/devconsole)
   - Click "New Item"
   - Upload `.zip` file
   - Accept developer agreement

4. **Fill Store Listing**
   - **Name:** TranquilFocus
   - **Summary:** Privacy-first focus tracking with gentle feedback
   - **Description:** (Use marketing copy from below)
   - **Category:** Productivity
   - **Language:** English (add more as needed)

5. **Set Privacy Practices**
   - Single purpose: Focus tracking
   - No remote code
   - Data usage: None (all local)
   - Privacy policy: (Link to GitHub)

6. **Submit for Review**
   - Review typically takes 1-3 business days
   - Address any feedback from reviewers

### Store Listing Copy

**Summary (132 chars max):**
```
Privacy-first focus tracking. Real-time feedback through a subtle overlay. No tracking, all local processing.
```

**Description:**
```
Stay focused and tranquil with real-time focus tracking that respects your privacy.

🎯 KEY FEATURES

• Real-time Focus Tracking
  Track your concentration through behavioral patterns - typing rhythm, mouse activity, and page engagement.

• Non-Intrusive Overlay
  A minimal color band (10px wide) shows your focus state at a glance. Blue = focused, orange = scattered.

• Two Modes
  - Tranquil: Silent monitoring, no interruptions
  - Assist: Gentle nudges when focus drops, celebrations for streaks

• 100% Private
  All processing happens locally in your browser. No data collection, no cloud sync, no tracking.

🔒 PRIVACY FIRST

• No keystroke logging (only timing patterns)
• No URL tracking
• No data sent to servers
• No persistent logs (only in-memory)
• Open source (auditable code)

⚡ SMART FEATURES

• Attack/release smoothing for natural transitions
• Intelligent throttling (max 1 nudge per 15 min)
• Works offline (no network required)
• Optimized for performance (<1% CPU)

🧘 PHILOSOPHY

Help users stay calm and focused without tracking them. TranquilFocus provides awareness without surveillance, feedback without interruption.

Perfect for developers, writers, students, and anyone who wants to improve focus while maintaining privacy.
```

---

## GitHub Releases

### Automated with GitHub Actions

**Workflow:** `.github/workflows/release.yml`

**Trigger:** Push a version tag

```bash
git tag v0.6.0
git push origin v0.6.0
```

**Actions will:**
1. Checkout code
2. Setup Node.js 18
3. Install dependencies
4. Run `npm run build`
5. Run `npm run zip`
6. Create GitHub Release
7. Attach `.zip` file
8. Add release notes

**Release will include:**
- `tranquilfocus-v0.6.0.zip` (ready for installation)
- Release notes with installation instructions
- Link to CHANGELOG.md

### Manual Release

If GitHub Actions not available:

```bash
# Build and package
npm run build
npm run zip

# Create release on GitHub
# 1. Go to Releases → Draft a new release
# 2. Create tag: v0.6.0
# 3. Upload: dist/tranquilfocus-v0.6.0.zip
# 4. Add release notes
# 5. Publish
```

---

## Versioning

TranquilFocus follows [Semantic Versioning](https://semver.org/):

**Format:** MAJOR.MINOR.PATCH

- **MAJOR:** Breaking changes (e.g., new manifest version)
- **MINOR:** New features (backward compatible)
- **PATCH:** Bug fixes (backward compatible)

**Examples:**
- `0.1.0` → Initial release
- `0.2.0` → Added focus algorithm (new feature)
- `0.2.1` → Fixed calculation bug (patch)
- `1.0.0` → First stable release

**Current:** v0.6.0 (beta, pre-1.0)

---

## Distribution Channels

### 1. Chrome Web Store (Recommended)

**Pros:**
- Automatic updates
- Trusted by users
- Easy discovery
- One-click install

**Cons:**
- Review process (1-3 days)
- $5 developer fee
- Store policies to follow

**Status:** Planned

### 2. GitHub Releases

**Pros:**
- Free
- Full control
- Open source distribution
- GitHub community

**Cons:**
- Manual installation
- No automatic updates
- Users must trust developer

**Status:** ✅ Automated via GitHub Actions

### 3. Direct Distribution

**Pros:**
- Total control
- Immediate availability
- No middleman

**Cons:**
- Users must manually update
- Less discoverable
- Trust issues

**Method:**
- Share `.zip` file directly
- Users load as unpacked extension
- Or email, cloud storage, etc.

---

## Optional: Landing Page

### Static Site Deployment

Deploy a marketing page with Vercel/Netlify:

**Create:** `landing/index.html`

```html
<!DOCTYPE html>
<html>
<head>
  <title>TranquilFocus - Privacy-First Focus Tracking</title>
  <!-- Marketing site -->
</head>
<body>
  <h1>TranquilFocus</h1>
  <p>Stay focused, stay tranquil</p>
  <a href="https://github.com/yourusername/tranquilfocus/releases">Download</a>
</body>
</html>
```

**Deploy to Vercel:**
```bash
cd landing
vercel deploy
```

**Or Netlify:**
```bash
cd landing
netlify deploy
```

**Not required** for the extension itself, only for marketing.

---

## Testing Before Release

### Pre-Release Checklist

**Functionality:**
- [ ] Extension loads without errors
- [ ] All features work as documented
- [ ] No console errors
- [ ] Performance acceptable
- [ ] Works in incognito mode

**Build:**
- [ ] `npm run build` succeeds
- [ ] `npm run zip` creates valid .zip
- [ ] .zip installs in clean Chrome profile
- [ ] All files included in package

**Documentation:**
- [ ] README.md up to date
- [ ] CHANGELOG.md updated
- [ ] Version bumped in manifest.json
- [ ] Screenshots current

**Cross-Browser:**
- [ ] Chrome (primary)
- [ ] Edge (Chromium)
- [ ] Brave (Chromium)

**Accessibility:**
- [ ] Keyboard navigation works
- [ ] Screen reader compatible
- [ ] Reduced motion respected

### Version Bump Checklist

Before releasing a new version:

1. Update version in `manifest.json`
2. Update version in `package.json`
3. Add entry to `CHANGELOG.md`
4. Update `README.md` if needed
5. Commit changes
6. Create and push tag
7. Verify GitHub Actions succeeded
8. Test downloaded .zip

---

## Continuous Integration

### GitHub Actions Workflow

**File:** `.github/workflows/release.yml`

**Triggers:**
- Tag push matching `v*.*.*`

**Jobs:**
1. **build** - Builds and packages extension
2. **release** - Creates GitHub Release with attachment

**Artifacts:**
- `tranquilfocus-v{version}.zip` attached to release

**Logs:** Check Actions tab on GitHub for build status

### Future CI/CD

**Potential additions:**
- Automated testing (Jest, Puppeteer)
- Linting (ESLint)
- Security scanning
- Automated Chrome Web Store upload (via API)

---

## Deployment Checklist

### Before Deployment

- [ ] All features tested
- [ ] No known critical bugs
- [ ] Documentation updated
- [ ] Version bumped
- [ ] CHANGELOG.md entry added
- [ ] Screenshots/demo GIF updated

### Deployment Steps

1. **Tag and Push**
   ```bash
   git tag v0.6.0
   git push origin v0.6.0
   ```

2. **Wait for GitHub Actions**
   - Check Actions tab for build status
   - Verify release created
   - Download and test .zip

3. **Submit to Chrome Web Store**
   - Upload .zip
   - Update store listing
   - Submit for review

4. **Announce**
   - Post on GitHub Discussions
   - Update README.md
   - Social media (optional)

### After Deployment

- [ ] Monitor for issues
- [ ] Respond to user feedback
- [ ] Plan next version
- [ ] Update roadmap

---

## Troubleshooting

### Build Fails

**Error:** `Cannot find module 'archiver'`
```bash
npm install
```

**Error:** `EACCES: permission denied`
```bash
sudo npm run build  # Not recommended
# OR
chmod +x scripts/*.js
```

### Zip Fails

**Error:** `dist/ not found`
```bash
npm run build  # Run build first
npm run zip
```

### GitHub Actions Fails

- Check Actions tab for error logs
- Verify Node.js version (18+)
- Check `package.json` scripts
- Ensure `archiver` in devDependencies

### Extension Won't Load

- Verify `manifest.json` is valid JSON
- Check for syntax errors
- Review errors in `chrome://extensions/`
- Try fresh Chrome profile

---

## Resources

**Chrome Extension Docs:**
- [Manifest V3 Guide](https://developer.chrome.com/docs/extensions/mv3/intro/)
- [Publishing Guide](https://developer.chrome.com/docs/webstore/publish/)

**Tools:**
- [Chrome Extension Source Viewer](https://chrome.google.com/webstore/detail/chrome-extension-source-v/jifpbeccnghkjeaalbbjmodiffmgedin)
- [Extension Reloader](https://chrome.google.com/webstore/detail/extensions-reloader/fimgfedafeadlieiabdeeaodndnlbhid)

**Testing:**
- [Puppeteer](https://pptr.dev/) - Automated browser testing
- [Jest](https://jestjs.io/) - Unit testing

---

**Last Updated:** 2024  
**Branch:** docs/build-deliver

