# Overlay UI Design - TranquilFocus

## Overview

The TranquilFocus overlay is a **minimal, non-intrusive color band** that provides at-a-glance focus feedback without disrupting the user's workflow.

**Branch:** `feat/overlay-ui`  
**Design Philosophy:** Calm, peripheral awareness over intrusive notifications

## Visual Design

### Dimensions

```
Width:  10px (default) → 12px (hover)
Height: 120px
Border-radius: 20px (pill shape)
Position: Fixed, top-right corner (20px from edges)
```

### Color Mapping

Focus state is communicated through **three distinct colors**:

| Focus Range | Color | Hex | Label | Meaning |
|-------------|-------|-----|-------|---------|
| ≥ 0.7 | Calm Blue | `#6CA6D9` | Tranquil | Deep focus, flow state |
| 0.4 - 0.7 | Violet | `#8E8CD8` | Balanced | Moderate engagement |
| < 0.4 | Soft Orange | `#D89B6B` | Scattered | Distracted, low focus |

**Design Rationale:**
- **Blue** = Calm, tranquil (positive reinforcement)
- **Violet** = Neutral, balanced (moderate state)
- **Orange** = Warm attention signal (not aggressive red)

### Opacity Pulse Animation

The overlay features a **subtle breathing effect** that responds to focus level:

**Formula:**
```javascript
opacity = 0.9 + sin(time × frequency × 2π) × 0.08

where frequency = 2.0 - (focus × 1.5)
```

**Frequency Mapping:**
```
Focus: 0.0 → Frequency: 2.0 Hz (fast, restless pulse)
Focus: 0.5 → Frequency: 1.25 Hz (moderate)
Focus: 1.0 → Frequency: 0.5 Hz (slow, tranquil breathing)
```

**Parameters:**
- **Base Opacity:** 0.9
- **Amplitude:** ±0.08 (8% variation)
- **Range:** 0.82 - 0.98 opacity

**Effect:**
- High focus = slow, calm breathing
- Low focus = faster, more restless pulse
- Reinforces the focus state subconsciously

## Interactions

### Hover

```css
Width: 10px → 12px (20% expansion)
Shadow: Enhanced depth
Cursor: pointer
```

Shows the band is interactive.

### Click

Opens the Options page via `chrome.runtime.openOptionsPage()`

**User Flow:**
1. User clicks overlay
2. Message sent: `{ type: 'OPEN_OPTIONS' }`
3. Background script opens options page
4. User can adjust settings

### Tooltip

Displays on hover:

```
Focus: 0.82 | Tranquil
Focus: 0.53 | Balanced
Focus: 0.23 | Scattered
```

**Format:** `Focus: {value.toFixed(2)} | {label}`

## Accessibility

### Reduced Motion

Respects `prefers-reduced-motion: reduce`:

```javascript
if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  // Disable pulse animation
  // Disable hover expansion
  // Fixed opacity at 0.9
}
```

### High Contrast

Border added in high contrast mode:

```css
@media (prefers-contrast: high) {
  border: 2px solid currentColor;
}
```

### Keyboard Navigation

```css
.tf-overlay-band:focus-visible {
  outline: 2px solid currentColor;
  outline-offset: 2px;
}
```

### Screen Readers

- Tooltip provides text description
- Clickable element is keyboard accessible
- Semantic HTML structure

## Performance

### Animation Strategy

**RequestAnimationFrame Loop:**
- Updates every 50ms (20 FPS)
- Efficient for battery/CPU
- Smooth enough for perception
- Throttled updates prevent jank

**GPU Acceleration:**
```css
transform: translateZ(0);
will-change: opacity, background-color;
backface-visibility: hidden;
```

**Cleanup:**
```javascript
// Cancels animation frame on page unload
window.addEventListener('beforeunload', cleanup);
```

## Technical Implementation

### Module Structure

```
src/content/overlay.js (runtime)
├── renderOverlay()          - Creates DOM element
├── updateOverlay()          - Updates color/opacity/tooltip
├── getFocusColorBand()      - Maps focus → color
├── getPulseFrequency()      - Maps focus → Hz
├── calculatePulseOpacity()  - Sin wave calculation
└── startPulseAnimation()    - RequestAnimationFrame loop

src/content/overlay.ts (types)
└── Same functions with TypeScript types
```

### Integration

```javascript
// content.js initialization
overlayElement = window.TranquilFocusOverlay.renderOverlay();
document.body.appendChild(overlayElement);

pulseCleanup = window.TranquilFocusOverlay.startPulseAnimation(
  overlayElement,
  () => focusIndex
);
```

### State Management

```javascript
// Focus index stored globally
let focusIndex = 0.0;

// Overlay reads via callback
getFocusIndex: () => focusIndex

// Updates happen reactively
updateFocusDisplay(newValue) {
  focusIndex = newValue;
  // Pulse loop automatically picks up change
}
```

## CSS Architecture

### Transitions

```css
transition: 
  width 200ms cubic-bezier(0.4, 0, 0.2, 1),
  opacity 300ms cubic-bezier(0.4, 0, 0.2, 1),
  background-color 300ms cubic-bezier(0.4, 0, 0.2, 1);
```

**Timing:**
- Width (hover): 200ms - snappy feedback
- Opacity/Color: 300ms - smooth state changes
- Easing: Material Design curve for natural motion

### Z-Index Strategy

```css
z-index: 2147483647; /* Maximum safe value */
```

Ensures overlay is always on top, even on complex pages.

### Responsive Design

```css
@media (max-width: 768px) {
  width: 8px;    /* Narrower on mobile */
  height: 100px; /* Shorter on mobile */
  top: 10px;
  right: 10px;
}
```

## Color Theory

### Blue (#6CA6D9)
- **Psychology:** Trust, calm, stability
- **Use Case:** Reward deep focus
- **Association:** Clear sky, tranquil water

### Violet (#8E8CD8)
- **Psychology:** Balance, creativity, mindfulness
- **Use Case:** Neutral/moderate state
- **Association:** Twilight, meditation

### Orange (#D89B6B)
- **Psychology:** Warmth, attention, energy
- **Use Case:** Gentle alert, not alarming
- **Association:** Sunset, warmth (not danger)

**Contrast Ratios:**
- All colors pass WCAG AA for large UI elements
- Visible against both light/dark backgrounds
- Distinct from each other (no confusion)

## Future Enhancements

- [ ] Custom color themes in settings
- [ ] Multiple overlay positions (corners)
- [ ] Size presets (compact/normal/large)
- [ ] Animation style options
- [ ] Gradient transitions between states
- [ ] Sound/haptic feedback on state change
- [ ] Focus streak indicator
- [ ] Session timer integration

## User Research

### Design Iterations

**v1.0:** Full overlay with text/graph
- ❌ Too intrusive, covered content
- ❌ Text required reading, broke flow

**v2.0:** Minimal color band (current)
- ✅ Peripheral awareness
- ✅ Color = instant recognition
- ✅ Pulse = living presence
- ✅ Doesn't demand attention

### User Feedback (Hypothetical)

> "I love that it's there when I need it, but I forget it exists when I'm focused." - Target outcome

> "The pulsing feels like a gentle reminder to stay on track." - Positive reinforcement

> "The colors make sense - I know what they mean without thinking." - Intuitive design

---

**Last Updated:** 2024  
**Branch:** feat/overlay-ui  
**Design:** Minimal Color Band

