# TranquilFocus Visual Guide

## Overlay Color States

### High Focus (≥ 0.7) - "Tranquil"

```
┌─────────────────────────────────────────┐
│                                    ███  │ 🔵 Calm Blue #6CA6D9
│                                    ███  │
│                                    ███  │ • Slow breathing (0.5 Hz)
│                                    ███  │ • Deep focus / flow state
│                                    ███  │ • Reward state
│                                    ███  │
│                                         │ Tooltip: "Focus: 0.82 | Tranquil"
└─────────────────────────────────────────┘
```

**When it appears:**
- Steady typing rhythm
- Long dwell time (3+ min)
- Minimal mouse movement
- Consistent input

**User feeling:** Productive, in the zone, flow

---

### Moderate Focus (0.4 - 0.7) - "Balanced"

```
┌─────────────────────────────────────────┐
│                                    ███  │ 🟣 Violet #8E8CD8
│                                    ███  │
│                                    ███  │ • Moderate pulse (1.25 Hz)
│                                    ███  │ • Engaged work
│                                    ███  │ • Neutral state
│                                    ███  │
│                                         │ Tooltip: "Focus: 0.53 | Balanced"
└─────────────────────────────────────────┘
```

**When it appears:**
- Mixed typing and reading
- Moderate dwell time (1-3 min)
- Some mouse activity
- Normal work pace

**User feeling:** Getting things done, comfortable

---

### Low Focus (< 0.4) - "Scattered"

```
┌─────────────────────────────────────────┐
│                                    ███  │ 🟠 Soft Orange #D89B6B
│                                    ███  │
│                                    ███  │ • Fast pulse (2.0 Hz)
│                                    ███  │ • Distracted state
│                                    ███  │ • Gentle alert
│                                    ███  │
│                                         │ Tooltip: "Focus: 0.23 | Scattered"
└─────────────────────────────────────────┘
```

**When it appears:**
- Erratic typing or no typing
- Short dwell time (<1 min)
- High mouse movement
- Tab switching

**User feeling:** Distracted, need to refocus

---

## Pulse Animation

### Visual Representation

```
Opacity over time (High Focus - Slow):

1.0 ┤
0.98┤     ╭─╮         ╭─╮
0.96┤    ╱   ╲       ╱   ╲
0.94┤   ╱     ╲     ╱     ╲
0.92┤  ╱       ╲   ╱       ╲
0.90┤─╯         ╰─╯         ╰─
0.88┤
0.86┤
0.84┤
0.82┤
    └────────────────────────────> Time
    0s      2s      4s      6s
    
    Frequency: 0.5 Hz (slow, calm)


Opacity over time (Low Focus - Fast):

1.0 ┤
0.98┤  ╭╮  ╭╮  ╭╮  ╭╮  ╭╮  ╭╮
0.96┤ ╱╰╮╱╰╮╱╰╮╱╰╮╱╰╮╱╰╮
0.94┤╱  ╰╯  ╰╯  ╰╯  ╰╯  ╰╯
0.92┤
0.90┤────────────────────────
0.88┤
0.86┤
0.84┤
0.82┤
    └────────────────────────────> Time
    0s      2s      4s      6s
    
    Frequency: 2.0 Hz (fast, restless)
```

### Mathematical Formula

```
opacity(t) = 0.9 + sin(t × f × 2π) × 0.08

where:
  t = time in seconds
  f = 2.0 - (focusIndex × 1.5)  // frequency in Hz
  
Example:
  focusIndex = 0.8 (high focus)
  f = 2.0 - (0.8 × 1.5) = 0.8 Hz
  opacity(0) = 0.9 + sin(0) × 0.08 = 0.90
  opacity(0.5) = 0.9 + sin(0.5×0.8×2π) × 0.08 ≈ 0.97
```

---

## Interactive States

### Default State

```
┌───────┐
│  10px │  Width: 10px
│       │  Height: 120px
│       │  Opacity: 0.82-0.98 (pulsing)
│       │  Border-radius: 20px
│       │  Shadow: subtle
│       │
│       │
│       │
└───────┘
```

### Hover State

```
┌─────────┐
│   12px  │  Width: 12px (expanded)
│         │  Shadow: enhanced
│         │  Cursor: pointer
│         │  Tooltip: visible
│         │
│         │
│         │
│         │
└─────────┘

Tooltip appears:
┌──────────────────────┐
│ Focus: 0.82 | Tranquil │
└──────────────────────┘
```

### Click State

```
┌───────┐
│ 9.5px │  Scale: 0.95 (momentary)
│       │  
│       │  Action: Opens Options page
│       │  
│       │
│       │
│       │
└───────┘
```

---

## Positioning

```
Browser Window:
┌────────────────────────────────────────────────────────────┐
│  [Tab 1] [Tab 2] [Tab 3]                          [×][□][−]│
├────────────────────────────────────────────────────────────┤
│  ← → ⟳  https://example.com                    🔍 ⚙  👤  │
├────────────────────────────────────────────────────────────┤
│                                                        ███  │ ← 20px from top
│  Page Content                                         ███  │ ← 20px from right
│                                                        ███  │
│                                                        ███  │
│                                                        ███  │
│                                                        ███  │
│                                                        ███  │
│                                                             │
│                                                             │
│                                                             │
│                                                             │
└────────────────────────────────────────────────────────────┘
```

**Desktop:**
- Top: 20px
- Right: 20px
- Width: 10px
- Height: 120px

**Mobile:**
- Top: 10px
- Right: 10px
- Width: 8px
- Height: 100px

---

## Color Transitions

```
Timeline of focus change:

Focus Index:  0.3 ────────────────────> 0.8
                    (start typing)

Color:       🟠 Orange ───────> 🟣 Violet ───────> 🔵 Blue
             Scattered      Balanced          Tranquil
             
Transition:  ├─── 300ms ───┤─── 300ms ───┤
             smooth cubic-bezier easing
             
Pulse Speed: Fast (2.0 Hz) ────────────> Slow (0.5 Hz)
             Restless                     Calm
```

---

## Accessibility Modes

### Prefers Reduced Motion

```
BEFORE (animated):              AFTER (static):
┌───────┐                       ┌───────┐
│  ███  │ opacity: 0.82-0.98   │  ███  │ opacity: 0.90 (fixed)
│  ███  │ pulsing               │  ███  │ no animation
│  ███  │                       │  ███  │
│  ███  │ hover: expands        │  ███  │ hover: no change
└───────┘                       └───────┘
```

### High Contrast Mode

```
┌───────┐
│ ┌───┐ │ 2px border added
│ │███│ │ Better visibility
│ │███│ │ Color maintained
│ │███│ │ 
│ └───┘ │
└───────┘
```

---

## Comparison: Old vs New

### Old Overlay (v0.1.0)

```
┌──────────────────────┐
│ Focus                │ ← Large box
│ 0.82                 │ ← Numbers
│ ████████░░           │ ← Progress bar
└──────────────────────┘

• Intrusive (covers content)
• Requires reading
• Static colors
• More screen space
```

### New Overlay (v0.3.0)

```
███  ← Minimal band

• Peripheral awareness
• Color = instant info
• Breathing animation
• Tiny footprint (10×120px)
```

---

## Design Rationale

### Why a vertical band?

✅ **Peripheral vision** - Top-right is outside main focus area  
✅ **Compact** - Takes minimal space  
✅ **Always visible** - Fixed position, scrolls with page  
✅ **Universal** - Works on any website  

### Why these colors?

🔵 **Blue** - Scientifically linked to calm, trust, productivity  
🟣 **Violet** - Neutral, balanced, creative  
🟠 **Orange** - Warm attention, not alarming like red  

### Why breathing animation?

✨ **Living presence** - Feels organic, not static  
✨ **Subconscious cue** - Mirrors breath, induces calm  
✨ **Adaptive feedback** - Speed changes with state  
✨ **Non-intrusive** - Subtle (±8%), doesn't distract  

---

## User Experience Flow

```
1. User starts focus session
   ↓
2. Overlay appears (fade in)
   Color: Violet (neutral)
   Pulse: Medium speed
   ↓
3. User begins focused work
   ↓
4. Color gradually shifts → Blue
   Pulse gradually slows
   Subconscious: "I'm in flow"
   ↓
5. User gets distracted
   ↓
6. Color gradually shifts → Orange
   Pulse speeds up
   Subconscious: "I'm losing focus"
   ↓
7. User sees orange, refocuses
   ↓
8. Color returns to Blue
   Positive reinforcement!
```

---

**Last Updated:** 2024  
**Branch:** feat/overlay-ui

