/**
 * UI Controls for TranquilFocus
 * Manages start/stop, sliders, and mode toggles
 */

export interface ControlsState {
  isRunning: boolean;
  isDayMode: boolean;
  intensity: number;
  assistMode: boolean;
}

export interface ControlsCallbacks {
  onStart: () => void;
  onStop: () => void;
  onDayModeToggle: (isDayMode: boolean) => void;
  onIntensityChange: (intensity: number) => void;
  onAssistModeToggle: (enabled: boolean) => void;
}

export class Controls {
  private container: HTMLElement;
  private state: ControlsState = {
    isRunning: false,
    isDayMode: true,
    intensity: 0.7,
    assistMode: false
  };
  private callbacks: ControlsCallbacks;

  private startButton!: HTMLButtonElement;
  private stopButton!: HTMLButtonElement;
  private dayButton!: HTMLButtonElement;
  private nightButton!: HTMLButtonElement;
  private intensitySlider!: HTMLInputElement;
  private intensityValue!: HTMLSpanElement;
  private assistToggle!: HTMLInputElement;

  constructor(container: HTMLElement, callbacks: ControlsCallbacks) {
    this.container = container;
    this.callbacks = callbacks;
    this.render();
  }

  private render(): void {
    this.container.innerHTML = `
      <div class="controls-panel">
        <h2 class="controls-title">TranquilFocus</h2>
        
        <div class="control-section">
          <h3>Session</h3>
          <div class="button-group">
            <button class="btn btn-primary" id="start-btn">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                <path d="M3 2v12l10-6z"/>
              </svg>
              Start
            </button>
            <button class="btn btn-secondary" id="stop-btn" disabled>
              <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                <rect x="3" y="3" width="10" height="10"/>
              </svg>
              Stop
            </button>
          </div>
        </div>

        <div class="control-section">
          <h3>Theme</h3>
          <div class="button-group">
            <button class="btn btn-toggle active" id="day-btn">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                <circle cx="8" cy="8" r="3"/>
                <path d="M8 1v2M8 13v2M15 8h-2M3 8H1M13.5 2.5l-1.4 1.4M3.9 12.1l-1.4 1.4M13.5 13.5l-1.4-1.4M3.9 3.9L2.5 2.5"/>
              </svg>
              Day
            </button>
            <button class="btn btn-toggle" id="night-btn">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                <path d="M6 0.5C3.5 1 2 3.5 2 6c0 3.3 2.7 6 6 6 2.5 0 5-1.5 5.5-4-0.5 0.5-2 1-3.5 1-3.3 0-6-2.7-6-6 0-1.5 0.5-3 1-3.5z"/>
              </svg>
              Night
            </button>
          </div>
        </div>

        <div class="control-section">
          <h3>Intensity</h3>
          <div class="slider-group">
            <input 
              type="range" 
              min="0" 
              max="100" 
              value="70" 
              class="slider" 
              id="intensity-slider"
            />
            <span class="slider-value" id="intensity-value">70%</span>
          </div>
        </div>

        <div class="control-section">
          <h3>Mode</h3>
          <div class="toggle-group">
            <label class="toggle-label">
              <input type="checkbox" id="assist-toggle" class="toggle-checkbox" />
              <span class="toggle-switch"></span>
              <span class="toggle-text">
                <strong>Assist Mode</strong>
                <small>Nudges & celebrations</small>
              </span>
            </label>
          </div>
        </div>

        <div class="control-section focus-display" id="focus-display">
          <h3>Focus Index</h3>
          <div class="focus-value">0.00</div>
          <div class="focus-label">Getting Started</div>
          <div class="focus-bar">
            <div class="focus-bar-fill" style="width: 0%"></div>
          </div>
        </div>

        <footer class="controls-footer">
          <p class="privacy-note">
            <svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor">
              <path d="M8 1l6 3v4c0 3.5-2.5 6.5-6 7.5-3.5-1-6-4-6-7.5V4l6-3z"/>
            </svg>
            All metrics computed locally • No data stored
          </p>
          <p class="version">v1.0.0 • © 2024</p>
        </footer>
      </div>
    `;

    // Get element references
    this.startButton = this.container.querySelector('#start-btn')!;
    this.stopButton = this.container.querySelector('#stop-btn')!;
    this.dayButton = this.container.querySelector('#day-btn')!;
    this.nightButton = this.container.querySelector('#night-btn')!;
    this.intensitySlider = this.container.querySelector('#intensity-slider')!;
    this.intensityValue = this.container.querySelector('#intensity-value')!;
    this.assistToggle = this.container.querySelector('#assist-toggle')!;

    // Attach event listeners
    this.attachEvents();
  }

  private attachEvents(): void {
    // Start/Stop buttons
    this.startButton.addEventListener('click', () => {
      this.state.isRunning = true;
      this.startButton.disabled = true;
      this.stopButton.disabled = false;
      this.callbacks.onStart();
    });

    this.stopButton.addEventListener('click', () => {
      this.state.isRunning = false;
      this.startButton.disabled = false;
      this.stopButton.disabled = true;
      this.callbacks.onStop();
    });

    // Day/Night toggle
    this.dayButton.addEventListener('click', () => {
      this.state.isDayMode = true;
      this.dayButton.classList.add('active');
      this.nightButton.classList.remove('active');
      this.callbacks.onDayModeToggle(true);
    });

    this.nightButton.addEventListener('click', () => {
      this.state.isDayMode = false;
      this.nightButton.classList.add('active');
      this.dayButton.classList.remove('active');
      this.callbacks.onDayModeToggle(false);
    });

    // Intensity slider
    this.intensitySlider.addEventListener('input', (e) => {
      const value = parseInt((e.target as HTMLInputElement).value);
      const intensity = value / 100;
      this.state.intensity = intensity;
      this.intensityValue.textContent = `${value}%`;
      this.callbacks.onIntensityChange(intensity);
    });

    // Assist mode toggle
    this.assistToggle.addEventListener('change', (e) => {
      const enabled = (e.target as HTMLInputElement).checked;
      this.state.assistMode = enabled;
      this.callbacks.onAssistModeToggle(enabled);
    });
  }

  /**
   * Update focus display
   */
  updateFocusDisplay(focusIndex: number, label: string): void {
    const display = this.container.querySelector('#focus-display');
    if (!display) return;

    const valueEl = display.querySelector('.focus-value');
    const labelEl = display.querySelector('.focus-label');
    const barFill = display.querySelector('.focus-bar-fill') as HTMLElement;

    if (valueEl) valueEl.textContent = focusIndex.toFixed(2);
    if (labelEl) labelEl.textContent = label;
    if (barFill) barFill.style.width = `${focusIndex * 100}%`;
  }

  /**
   * Auto-start the session
   */
  autoStart(): void {
    this.startButton.click();
  }

  /**
   * Get current state
   */
  getState(): ControlsState {
    return { ...this.state };
  }
}

