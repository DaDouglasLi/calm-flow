/**
 * Main application class - orchestrates all components
 */

import { FocusSensors } from './focus/sensors';
import { calculateFocusIndex, AttackReleaseSmoother } from './focus/focusIndex';
import { TranquilScene } from './visual/scene';
import { Controls } from './ui/controls';
import { OverlayBand } from './ui/overlay';
import { ToastManager } from './ui/toast';
import { AssistMode } from './modes/assistMode';

export class TranquilFocusApp {
  private sensors: FocusSensors;
  private smoother: AttackReleaseSmoother;
  private scene: TranquilScene;
  private controls: Controls;
  private overlay: OverlayBand;
  private toastManager: ToastManager;
  private assistMode: AssistMode;
  private updateInterval: number | null = null;
  private isRunning = false;

  constructor() {
    // Initialize components
    this.sensors = new FocusSensors();
    this.smoother = new AttackReleaseSmoother(300, 1500);
    
    // Get DOM elements
    const canvas = document.getElementById('scene-canvas') as HTMLCanvasElement;
    const controlsContainer = document.getElementById('controls-container')!;
    const overlayContainer = document.getElementById('overlay-container')!;
    
    // Initialize visual components
    this.scene = new TranquilScene(canvas);
    this.overlay = new OverlayBand(overlayContainer);
    
    // Initialize toast and assist mode
    this.toastManager = new ToastManager();
    this.assistMode = new AssistMode(this.toastManager);
    
    // Initialize controls with callbacks
    this.controls = new Controls(controlsContainer, {
      onStart: () => this.start(),
      onStop: () => this.stop(),
      onDayModeToggle: (isDayMode) => this.scene.setDayMode(isDayMode),
      onIntensityChange: (intensity) => this.scene.setIntensity(intensity),
      onAssistModeToggle: (enabled) => {
        if (enabled) {
          this.assistMode.enable();
          this.toastManager.info('🤖 Assist Mode enabled');
        } else {
          this.assistMode.disable();
          this.toastManager.info('🧘 Tranquil Mode enabled');
        }
      }
    });

    // Start canvas animation immediately
    this.scene.start();
    
    // Auto-start sensors on first interaction
    this.setupAutoStart();
  }

  private setupAutoStart(): void {
    const autoStartHandler = () => {
      if (!this.isRunning) {
        this.controls.autoStart();
      }
      // Remove listeners after first trigger
      document.removeEventListener('keydown', autoStartHandler);
      document.removeEventListener('mousemove', autoStartHandler);
    };

    document.addEventListener('keydown', autoStartHandler, { once: true, passive: true });
    document.addEventListener('mousemove', autoStartHandler, { once: true, passive: true });
  }

  /**
   * Start focus tracking session
   */
  start(): void {
    if (this.isRunning) return;
    
    this.isRunning = true;
    this.sensors.start();
    this.smoother.reset();
    
    // Update focus index at 10Hz (every 100ms)
    this.updateInterval = window.setInterval(() => {
      this.updateFocus();
    }, 100);
  }

  /**
   * Stop focus tracking session
   */
  stop(): void {
    if (!this.isRunning) return;
    
    this.isRunning = false;
    this.sensors.stop();
    
    if (this.updateInterval !== null) {
      clearInterval(this.updateInterval);
      this.updateInterval = null;
    }
  }

  /**
   * Update focus index and visuals
   */
  private updateFocus(): void {
    // Get sensor data
    const sensorData = this.sensors.getData();
    
    // Calculate raw focus index
    const rawFocusIndex = calculateFocusIndex(sensorData);
    
    // Apply smoothing
    const smoothedFocusIndex = this.smoother.smooth(rawFocusIndex);
    
    // Update visuals
    this.scene.setFocusIndex(smoothedFocusIndex);
    
    // Get current color label
    const label = this.scene.getColorLabel();
    
    // Update UI
    this.controls.updateFocusDisplay(smoothedFocusIndex, label);
    this.overlay.update(smoothedFocusIndex, label);
    
    // Update assist mode
    this.assistMode.update(smoothedFocusIndex);
  }

  /**
   * Cleanup on app destroy
   */
  destroy(): void {
    this.stop();
    this.sensors.stop();
    this.scene.destroy();
  }
}

