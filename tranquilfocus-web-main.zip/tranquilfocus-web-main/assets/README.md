# Assets

This directory contains visual assets for TranquilFocus documentation.

## Files

- **logo.svg** - TranquilFocus logo (concentric focus ripples)
- **screenshot.png** - Application screenshot (add your own)
- **demo.gif** - Animated demo of the app in action (add your own)

## Creating Screenshots

To capture the perfect screenshot:

1. Run `npm run dev`
2. Start a focus session
3. Let the visual evolve for 30-60 seconds
4. Capture the full window
5. Save as `screenshot.png`

## Creating Demo GIF

Use tools like:
- [LICEcap](https://www.cockos.com/licecap/) (Windows/Mac)
- [Kap](https://getkap.co/) (Mac)
- [ScreenToGif](https://www.screentogif.com/) (Windows)

Recommended settings:
- Duration: 10-15 seconds
- FPS: 30
- Size: 1200x800 or similar
- Show typing/mouse interaction
- Capture the focus index changing

Save as `demo.gif`

