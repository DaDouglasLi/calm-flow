# Popup & Options Documentation

## Overview

TranquilFocus provides a minimal popup interface for quick status checks and mode switching, plus a comprehensive options page for customization.

**Branch:** `feat/popup-options`

---

## Popup Interface

### Design

**Dimensions:** 320px width, auto height  
**Style:** Gradient background with glassmorphism

**Color Scheme:**
- Background: Linear gradient (#667eea → #764ba2)
- Cards: Semi-transparent white with backdrop blur
- Text: White on gradient, color-coded focus values

### Components

#### 1. Focus Display

```
┌─────────────────────────┐
│   Current Focus         │
│      0.82               │ ← Color-coded
│     Tranquil            │
└─────────────────────────┘
```

**Color Coding:**
- **≥ 0.7**: Calm Blue (#6CA6D9) - "Tranquil"
- **0.4-0.7**: White - "Balanced"
- **< 0.4**: Soft Orange (#D89B6B) - "Scattered"

**Data Source:**
- Subscribes to `FOCUS_UPDATE` messages from background
- Polls every 2 seconds as backup
- Requests on popup open via `GET_FOCUS`

#### 2. Mode Selection

```
┌──────────┬──────────┐
│ 🧘       │ 🤝       │
│ Tranquil │ Assist   │
│ Silent   │ Nudge    │
└──────────┴──────────┘
```

**Tranquil Mode (Default):**
- Silent monitoring only
- No notifications
- Just visual indicator
- For users who self-regulate

**Assist Mode:**
- Active monitoring
- Gentle nudges when focus drops
- Trigger: focus < 0.35 for 2+ minutes
- Notification: Silent, non-intrusive

**Interaction:**
- Click to switch modes
- Active mode highlighted (white background)
- Sends `SET_MODE` message to background
- Persists to `chrome.storage.local`

#### 3. Privacy Notice

```
┌─────────────────────────────────────┐
│ 🔒 All metrics local.               │
│    No keystrokes persisted.         │
└─────────────────────────────────────┘
```

**Purpose:** Reassure users about privacy  
**Truth:** All data stays in browser, no cloud sync

#### 4. Settings Link

```
⚙️ Settings
```

**Action:** Opens `options.html` in new tab  
**Method:** `chrome.runtime.openOptionsPage()`

---

## Options Page

### Design

**Layout:** Centered, max-width 700px  
**Header:** Gradient (#667eea → #764ba2)  
**Content:** White card with sections

### Sections

#### 1. Appearance

```
Show Overlay                    ⚪ → 🟢
Display focus indicator on pages

Enable Pulse Animation          ⚪ → 🟢
Breathing effect on overlay

Color Theme                     [System ▼]
Appearance preference
```

**Settings:**
- `showOverlay` (boolean, default: true)
- `pulseEnabled` (boolean, default: true)
- `colorTheme` (string: 'system'/'day'/'night', default: 'system')

**Effects:**
- Changes broadcast to content scripts immediately
- Overlay shows/hides
- Pulse starts/stops
- Theme applied (future feature)

#### 2. Focus Settings

```
Minimum Focus for Tranquil     [0.70]
Threshold to show "Tranquil" state (0.0 - 1.0)
```

**Setting:**
- `minFocusForTranquil` (number, default: 0.70)
- Range: 0.0 - 1.0
- Step: 0.05

**Effect:**
- Determines when to show "Tranquil" label
- Used for color band thresholds
- Future: Could trigger rewards/celebrations

#### 3. Assist Mode

```
Low Focus Threshold            [0.35]
Show nudge when below

Time Before Nudge (minutes)    [2]
Wait time before showing nudge
```

**Settings:**
- `assistThreshold` (number, default: 0.35)
- `assistDelay` (number, default: 2 minutes)

**Logic:**
```javascript
if (currentMode === 'assist') {
  if (focusIndex < assistThreshold) {
    startTimer();
    if (elapsed >= assistDelay) {
      showNudge();
    }
  }
}
```

#### 4. Data & Privacy

```
[📊 Export Metrics (JSON)]  [🗑️ Clear History]

🔒 Privacy: All data is stored locally on your device.
No keystrokes or sensitive information is persisted.
Only anonymized focus metrics are temporarily cached.
```

**Actions:**
- **Export Metrics**: Placeholder (disabled)
- **Clear History**: Removes `sensorHistory` from storage

**Privacy Statement:**
- Transparent about data storage
- Emphasizes local-only
- No cloud, no tracking
- Open source spirit

---

## State Management

### Background Script State

```javascript
// Mode
let currentMode = 'tranquil' | 'assist'

// Settings cache
let settings = {
  showOverlay: boolean,
  pulseEnabled: boolean,
  colorTheme: 'day' | 'night' | 'system',
  minFocusForTranquil: number,
  assistThreshold: number,
  assistDelay: number
}

// Assist mode tracking
let lowFocusStartTime = null
```

### Storage Schema

**Local Storage (`chrome.storage.local`):**
```json
{
  "focusIndex": 0.82,
  "isRunning": true,
  "mode": "tranquil",
  "sensorHistory": [...]
}
```

**Sync Storage (`chrome.storage.sync`):**
```json
{
  "showOverlay": true,
  "pulseEnabled": true,
  "colorTheme": "system",
  "minFocusForTranquil": 0.70,
  "assistThreshold": 0.35,
  "assistDelay": 2
}
```

---

## Message Protocol

### Popup → Background

**GET_FOCUS:**
```javascript
chrome.runtime.sendMessage({
  type: 'GET_FOCUS'
}, (response) => {
  // response.value = current focus index
});
```

**SET_MODE:**
```javascript
chrome.runtime.sendMessage({
  type: 'SET_MODE',
  mode: 'tranquil' | 'assist'
});
```

### Background → Popup

**FOCUS_UPDATE:**
```javascript
{
  type: 'FOCUS_UPDATE',
  value: 0.82
}
```

### Options → Background

**SETTINGS_UPDATE:**
```javascript
chrome.runtime.sendMessage({
  type: 'SETTINGS_UPDATE',
  settings: { showOverlay: false }
});
```

### Background → Content Scripts

**SETTINGS_UPDATE:**
```javascript
chrome.tabs.sendMessage(tabId, {
  type: 'SETTINGS_UPDATE',
  settings: { pulseEnabled: false }
});
```

---

## Assist Mode Details

### Trigger Logic

```
Timeline:

t=0    Focus drops to 0.32 (< 0.35 threshold)
       lowFocusStartTime = Date.now()
       
t=60s  Still at 0.30
       elapsed = 60s < 120s (2 min)
       No action yet
       
t=120s Still at 0.28
       elapsed = 120s >= 120s
       showNudge() → Notification appears
       lowFocusStartTime = null (reset)
       
t=130s Focus recovers to 0.50
       lowFocusStartTime = null (already reset)
```

### Notification

**Chrome Notification API:**
```javascript
chrome.notifications.create({
  type: 'basic',
  iconUrl: 'icons/icon48.png',
  title: 'TranquilFocus',
  message: 'Your focus seems scattered. Time for a brief pause? 🧘',
  priority: 0,  // Low priority
  silent: true  // No sound
});
```

**Design Philosophy:**
- **Gentle**: Suggests, doesn't demand
- **Positive**: "Time for a pause" not "You're distracted"
- **Silent**: No jarring sounds
- **Infrequent**: Only after sustained low focus
- **Emoji**: Friendly, approachable 🧘

### User Experience

**Good UX:**
```
User working → Gets distracted → Notification after 2 min
→ User takes break → Returns refreshed → Focus restored
```

**Avoids:**
- Frequent interruptions
- Accusatory tone
- Loud alerts
- Immediate triggers (30s grace period)

---

## UI/UX Patterns

### Toggle Switches

**States:**
- Off: Gray background, slider left
- On: Purple background (#667eea), slider right
- Transition: 300ms smooth

**Interaction:**
- Click anywhere on switch
- Visual feedback instant
- Save to storage
- Broadcast to relevant components

### Number Inputs

**Validation:**
```javascript
input.addEventListener('change', () => {
  const value = parseFloat(input.value);
  if (value >= min && value <= max) {
    saveSetting(key, value);
  } else {
    input.value = defaultValue;
    showError();
  }
});
```

**Constraints:**
- `minFocusForTranquil`: 0.0 - 1.0, step 0.05
- `assistThreshold`: 0.0 - 1.0, step 0.05
- `assistDelay`: 1 - 10 minutes, step 1

### Select Dropdowns

**Custom Styling:**
- Matches extension design
- Custom arrow icon (SVG)
- Border highlights on focus
- Smooth transitions

---

## Accessibility

### Keyboard Navigation

- All controls keyboard accessible
- Tab order logical (top to bottom)
- Focus indicators visible
- Enter/Space activate toggles

### Screen Readers

- Semantic HTML (labels, descriptions)
- Toggle state announced
- Error messages readable
- Privacy statement accessible

### Visual

- High contrast text
- Color not sole indicator (icons + text)
- Large click targets (44px minimum)
- Clear focus outlines

---

## Future Enhancements

### Popup
- [ ] Session timer display
- [ ] Today's focus score
- [ ] Quick stats (avg focus, time focused)
- [ ] Pause/resume session

### Options
- [ ] Custom color themes
- [ ] Keyboard shortcuts
- [ ] Blacklist/whitelist domains
- [ ] Advanced focus algorithm tuning
- [ ] Data export (CSV, JSON)
- [ ] Import/export settings

---

**Last Updated:** 2024  
**Branch:** feat/popup-options  
**Version:** 0.4.0

