/**
 * Assist Mode - Intelligent interventions for focus
 * Provides nudges for low focus and celebrations for streaks
 */

import type { ToastManager } from '../ui/toast';

interface AssistState {
  enabled: boolean;
  lowFocusStartTime: number | null;
  highFocusStartTime: number | null;
  lastNudgeTime: number;
  lastCelebrationTime: number;
}

const LOW_FOCUS_THRESHOLD = 0.35;
const HIGH_FOCUS_THRESHOLD = 0.7;
const LOW_FOCUS_DURATION = 2 * 60 * 1000; // 2 minutes
const HIGH_FOCUS_DURATION = 5 * 60 * 1000; // 5 minutes
const THROTTLE_DURATION = 15 * 60 * 1000; // 15 minutes

const NUDGE_MESSAGES = [
  "💭 Take a 60s micro-break?",
  "🌊 Time for a quick breath?",
  "☕ Consider a brief pause",
  "🧘 Stretch for 60 seconds?",
  "👀 Look away from screen for a moment"
];

const CELEBRATION_MESSAGES = [
  "🎯 Great streak! Keep it up!",
  "✨ Excellent focus! You're in the zone!",
  "🔥 Amazing concentration! Well done!",
  "⭐ Fantastic focus session!",
  "🌟 You're crushing it! Great work!"
];

export class AssistMode {
  private state: AssistState;
  private toastManager: ToastManager;
  private audioContext: AudioContext | null = null;

  constructor(toastManager: ToastManager) {
    this.toastManager = toastManager;
    this.state = {
      enabled: false,
      lowFocusStartTime: null,
      highFocusStartTime: null,
      lastNudgeTime: 0,
      lastCelebrationTime: 0
    };
  }

  /**
   * Enable assist mode
   */
  enable(): void {
    this.state.enabled = true;
    this.resetState();
  }

  /**
   * Disable assist mode
   */
  disable(): void {
    this.state.enabled = false;
    this.resetState();
  }

  /**
   * Check if assist mode is enabled
   */
  isEnabled(): boolean {
    return this.state.enabled;
  }

  /**
   * Update assist mode based on current focus index
   */
  update(focusIndex: number): void {
    if (!this.state.enabled) return;

    const now = Date.now();

    // Check for low focus
    if (focusIndex < LOW_FOCUS_THRESHOLD) {
      if (this.state.lowFocusStartTime === null) {
        this.state.lowFocusStartTime = now;
      } else {
        const lowFocusDuration = now - this.state.lowFocusStartTime;
        if (lowFocusDuration >= LOW_FOCUS_DURATION) {
          this.checkNudge(now);
        }
      }
    } else {
      this.state.lowFocusStartTime = null;
    }

    // Check for high focus streak
    if (focusIndex >= HIGH_FOCUS_THRESHOLD) {
      if (this.state.highFocusStartTime === null) {
        this.state.highFocusStartTime = now;
      } else {
        const highFocusDuration = now - this.state.highFocusStartTime;
        if (highFocusDuration >= HIGH_FOCUS_DURATION) {
          this.checkCelebration(now);
        }
      }
    } else {
      this.state.highFocusStartTime = null;
    }
  }

  /**
   * Check if we should show a nudge
   */
  private checkNudge(now: number): void {
    // Throttle nudges
    if (now - this.state.lastNudgeTime < THROTTLE_DURATION) {
      return;
    }

    // Show nudge
    const message = this.getRandomMessage(NUDGE_MESSAGES);
    this.toastManager.nudge(message);
    
    this.state.lastNudgeTime = now;
    this.state.lowFocusStartTime = null; // Reset to avoid repeated nudges
  }

  /**
   * Check if we should show a celebration
   */
  private checkCelebration(now: number): void {
    // Throttle celebrations
    if (now - this.state.lastCelebrationTime < THROTTLE_DURATION) {
      return;
    }

    // Show celebration
    const message = this.getRandomMessage(CELEBRATION_MESSAGES);
    this.toastManager.success(message, 5000);
    
    // Play success chime
    this.playChime();
    
    this.state.lastCelebrationTime = now;
    this.state.highFocusStartTime = null; // Reset
  }

  /**
   * Play a success chime using Web Audio API
   */
  private playChime(): void {
    try {
      if (!this.audioContext) {
        this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      }

      const ctx = this.audioContext;
      const now = ctx.currentTime;

      // C major chord (C4, E4, G4)
      const frequencies = [261.63, 329.63, 392.00];
      
      frequencies.forEach((freq, index) => {
        const oscillator = ctx.createOscillator();
        const gainNode = ctx.createGain();

        oscillator.type = 'sine';
        oscillator.frequency.value = freq;

        // Very subtle volume (3%)
        gainNode.gain.setValueAtTime(0.03, now);
        gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.5);

        oscillator.connect(gainNode);
        gainNode.connect(ctx.destination);

        oscillator.start(now + index * 0.05);
        oscillator.stop(now + 0.5);
      });
    } catch (error) {
      // Silently fail if Web Audio is not available
      console.debug('Web Audio not available:', error);
    }
  }

  /**
   * Get a random message from an array
   */
  private getRandomMessage(messages: string[]): string {
    return messages[Math.floor(Math.random() * messages.length)];
  }

  /**
   * Reset internal state
   */
  private resetState(): void {
    this.state.lowFocusStartTime = null;
    this.state.highFocusStartTime = null;
  }
}

