/**
 * Application entry point
 */

import { TranquilFocusApp } from './app';
import './style.css';

// Wait for DOM to be ready
document.addEventListener('DOMContentLoaded', () => {
  // Initialize the application
  const app = new TranquilFocusApp();

  // Cleanup on window unload
  window.addEventListener('beforeunload', () => {
    app.destroy();
  });

  // Log startup
  console.log('🧘 TranquilFocus initialized');
  console.log('All metrics computed locally • No data stored');
});

