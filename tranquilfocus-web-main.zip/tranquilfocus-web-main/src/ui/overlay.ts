/**
 * Overlay status band - minimal visual feedback
 */

export class OverlayBand {
  private element: HTMLElement;

  constructor(container: HTMLElement) {
    this.element = document.createElement('div');
    this.element.className = 'overlay-band';
    container.appendChild(this.element);
  }

  /**
   * Update overlay appearance
   */
  update(focusIndex: number, label: string): void {
    // Update tooltip
    this.element.title = `Focus: ${focusIndex.toFixed(2)} | ${label}`;
    
    // Update color class
    this.element.className = 'overlay-band';
    if (focusIndex >= 0.7) {
      this.element.classList.add('tranquil');
    } else if (focusIndex >= 0.4) {
      this.element.classList.add('balanced');
    } else {
      this.element.classList.add('scattered');
    }
  }

  /**
   * Set visibility
   */
  setVisible(visible: boolean): void {
    this.element.style.display = visible ? 'block' : 'none';
  }
}

