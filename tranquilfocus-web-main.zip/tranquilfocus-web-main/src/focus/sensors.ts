/**
 * Behavior sensors for focus tracking
 * Monitors keyboard cadence, mouse activity, and idle time
 */

import { ema } from '../utils/math';

export interface SensorData {
  ikiMsArray: number[];        // Inter-keystroke intervals (last 50)
  mouseHz: number;             // Mouse movement frequency (EMA)
  dwellSec: number;            // Seconds since session start
  lastInputAt: number;         // Timestamp of last input event
}

const IKI_BUFFER_SIZE = 50;
const MOUSE_EMA_ALPHA = 0.3;
const MOUSE_SAMPLE_WINDOW = 1000; // 1 second window for Hz calculation

export class FocusSensors {
  private ikiMsArray: number[] = [];
  private lastKeystrokeAt = 0;
  private mouseHz = 0;
  private mouseMoveCount = 0;
  private lastMouseSampleTime = Date.now();
  private dwellStartTime = Date.now();
  private lastInputAt = 0;
  private active = false;

  // Event handlers (bound methods)
  private handleKeydown = (event: KeyboardEvent) => {
    const now = Date.now();
    this.lastInputAt = now;
    
    if (this.lastKeystrokeAt > 0) {
      const interval = now - this.lastKeystrokeAt;
      
      // Add to buffer
      this.ikiMsArray.push(interval);
      
      // Keep only last 50 intervals
      if (this.ikiMsArray.length > IKI_BUFFER_SIZE) {
        this.ikiMsArray.shift();
      }
    }
    
    this.lastKeystrokeAt = now;
  };

  private handleMousemove = (event: MouseEvent) => {
    const now = Date.now();
    this.lastInputAt = now;
    this.mouseMoveCount++;
    
    // Calculate Hz using EMA every sample window
    const elapsed = now - this.lastMouseSampleTime;
    if (elapsed >= MOUSE_SAMPLE_WINDOW) {
      const currentHz = (this.mouseMoveCount / elapsed) * 1000;
      
      // Apply exponential moving average
      if (this.mouseHz === 0) {
        this.mouseHz = currentHz;
      } else {
        this.mouseHz = ema(this.mouseHz, currentHz, MOUSE_EMA_ALPHA);
      }
      
      // Reset counters
      this.mouseMoveCount = 0;
      this.lastMouseSampleTime = now;
    }
  };

  /**
   * Start listening to input events
   */
  start(): void {
    if (this.active) return;
    
    this.active = true;
    this.dwellStartTime = Date.now();
    
    document.addEventListener('keydown', this.handleKeydown, { passive: true });
    document.addEventListener('mousemove', this.handleMousemove, { passive: true });
  }

  /**
   * Stop listening to input events
   */
  stop(): void {
    if (!this.active) return;
    
    this.active = false;
    
    document.removeEventListener('keydown', this.handleKeydown);
    document.removeEventListener('mousemove', this.handleMousemove);
  }

  /**
   * Get current sensor data snapshot
   */
  getData(): SensorData {
    const now = Date.now();
    const dwellSec = (now - this.dwellStartTime) / 1000;
    
    return {
      ikiMsArray: [...this.ikiMsArray],
      mouseHz: Number(this.mouseHz.toFixed(2)),
      dwellSec: Number(dwellSec.toFixed(2)),
      lastInputAt: this.lastInputAt
    };
  }

  /**
   * Reset all sensor data
   */
  reset(): void {
    this.ikiMsArray = [];
    this.lastKeystrokeAt = 0;
    this.mouseHz = 0;
    this.mouseMoveCount = 0;
    this.lastMouseSampleTime = Date.now();
    this.dwellStartTime = Date.now();
    this.lastInputAt = 0;
  }

  /**
   * Check if sensors are active
   */
  isActive(): boolean {
    return this.active;
  }
}

