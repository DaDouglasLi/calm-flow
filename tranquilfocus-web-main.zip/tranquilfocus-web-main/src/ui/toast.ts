/**
 * Toast notification system
 * Shows temporary messages for nudges and celebrations
 */

export type ToastType = 'info' | 'nudge' | 'success';

export interface ToastOptions {
  type: ToastType;
  message: string;
  duration?: number; // milliseconds
}

export class ToastManager {
  private container: HTMLElement;
  private activeToast: HTMLElement | null = null;
  private hideTimeout: number | null = null;

  constructor() {
    this.container = document.body;
  }

  /**
   * Show a toast notification
   */
  show(options: ToastOptions): void {
    // Remove any existing toast
    if (this.activeToast) {
      this.hide();
    }

    // Create toast element
    const toast = document.createElement('div');
    toast.className = `tf-toast tf-toast-${options.type}`;
    toast.textContent = options.message;
    toast.setAttribute('role', 'status');
    toast.setAttribute('aria-live', 'polite');

    // Add to DOM
    this.container.appendChild(toast);
    this.activeToast = toast;

    // Trigger show animation (after DOM insertion)
    requestAnimationFrame(() => {
      toast.classList.add('tf-toast-show');
    });

    // Auto-hide after duration
    const duration = options.duration || (options.type === 'success' ? 5000 : 4000);
    this.hideTimeout = window.setTimeout(() => {
      this.hide();
    }, duration);
  }

  /**
   * Hide the current toast
   */
  hide(): void {
    if (!this.activeToast) return;

    // Clear timeout
    if (this.hideTimeout !== null) {
      clearTimeout(this.hideTimeout);
      this.hideTimeout = null;
    }

    // Trigger hide animation
    this.activeToast.classList.remove('tf-toast-show');
    this.activeToast.classList.add('tf-toast-hide');

    // Remove from DOM after animation
    const toast = this.activeToast;
    setTimeout(() => {
      if (toast.parentNode) {
        toast.parentNode.removeChild(toast);
      }
    }, 300);

    this.activeToast = null;
  }

  /**
   * Show an info toast
   */
  info(message: string, duration?: number): void {
    this.show({ type: 'info', message, duration });
  }

  /**
   * Show a nudge toast (gentle warning)
   */
  nudge(message: string, duration?: number): void {
    this.show({ type: 'nudge', message, duration });
  }

  /**
   * Show a success/celebration toast
   */
  success(message: string, duration?: number): void {
    this.show({ type: 'success', message, duration });
  }
}

