# 🧘 TranquilFocus

A meditative focus tracker with tranquil visual feedback. TranquilFocus transforms your keyboard and mouse activity into a peaceful, evolving visual experience that reflects your current focus state.

![TranquilFocus Demo](./assets/demo.gif)

## ✨ Features

### 🎯 Real-Time Focus Tracking
- **Focus Index** (0-1) computed from behavioral patterns
- Typing cadence analysis (inter-keystroke intervals)
- Mouse movement frequency monitoring
- Dwell time and idle detection
- Smooth attack/release transitions

### 🎨 Tranquil Visual Feedback
- Mesmerizing Perlin noise flow field animation
- Color-coded focus states:
  - 🔵 **Tranquil** (0.7-1.0): Calm blue tones
  - 💜 **Balanced** (0.4-0.7): Violet harmony
  - 🟠 **Scattered** (0.0-0.4): Warm orange
- 60 FPS canvas rendering with DPR scaling
- Responsive particle system

### 🎛️ Full Control
- **Start/Stop** focus sessions
- **Day/Night** theme toggle
- **Intensity** slider (0-100%)
- Live focus index display with progress bar
- Minimal overlay band indicator

### 🔒 Privacy-First
- **100% local computation** - no server, no analytics
- **No data storage** - all metrics computed in-memory
- **Open source** - inspect the code yourself

## 🚀 Quick Start

### Installation

```bash
# Clone or download the project
cd tranquilfocus-web

# Install dependencies
npm install

# Start development server
npm run dev
```

The app will open at `http://localhost:3000`

### Build for Production

```bash
# Build optimized static files
npm run build

# Preview production build
npm run preview
```

Output will be in `dist/` folder - ready for deployment!

## 📦 Deployment

TranquilFocus is a static web app that can be deployed anywhere:

### Vercel (Recommended)

1. Install Vercel CLI: `npm i -g vercel`
2. Run: `vercel`
3. Follow prompts - done!

Or use the [Vercel Dashboard](https://vercel.com/new):
- Import your Git repository
- Framework preset: Vite
- Build command: `npm run build`
- Output directory: `dist`

### Netlify

1. Drag and drop the `dist/` folder to [Netlify Drop](https://app.netlify.com/drop)

Or connect your Git repository:
- Build command: `npm run build`
- Publish directory: `dist`

### GitHub Pages

```bash
npm run build
cd dist
git init
git add -A
git commit -m 'Deploy'
git push -f git@github.com:username/repo.git main:gh-pages
```

### Other Hosts

Any static hosting works: AWS S3, Cloudflare Pages, Surge, etc.

## 🧩 Project Structure

```
tranquilfocus-web/
├─ index.html              # Entry HTML
├─ src/
│  ├─ main.ts              # Application bootstrap
│  ├─ app.ts               # Main app orchestration
│  ├─ style.css            # Global styles
│  ├─ focus/
│  │  ├─ sensors.ts        # Keyboard/mouse event listeners
│  │  └─ focusIndex.ts     # Focus computation & smoothing
│  ├─ visual/
│  │  ├─ scene.ts          # Canvas animation (Perlin flow field)
│  │  └─ colors.ts         # Color palettes & themes
│  ├─ ui/
│  │  ├─ controls.ts       # Control panel (buttons, sliders)
│  │  └─ overlay.ts        # Minimal overlay band
│  └─ utils/
│     └─ math.ts           # Math utilities (lerp, clamp, variance)
├─ public/                 # Static assets
├─ assets/                 # Documentation assets
├─ package.json
├─ tsconfig.json
├─ vite.config.js
└─ README.md
```

## 🎨 How It Works

### Focus Index Algorithm

The Focus Index is a weighted composite of multiple behavioral signals:

```
FocusIndex = 0.4×TypingStability + 0.35×Dwell - 0.15×MouseJitter - 0.10×Idle
```

**Components:**

1. **Typing Stability** (40% weight)
   - Measures consistency in inter-keystroke intervals
   - Low variance = high focus
   - Buffer: last 50 keystrokes

2. **Dwell Score** (35% weight)
   - Time spent in current session
   - Saturates at 3 minutes

3. **Mouse Jitter** (-15% weight)
   - Movement frequency (Hz)
   - High movement = distraction
   - Uses exponential moving average

4. **Idle Time** (-10% weight)
   - Time since last input
   - Caps at 5 seconds

### Smoothing

Attack/Release smoother provides natural transitions:
- **Attack** (fast rise): 300ms time constant
- **Release** (slow fall): 1500ms time constant

Uses exponential moving average: `α = 1 - e^(-Δt / τ)`

### Visual Rendering

**Perlin Noise Flow Field:**
- Particles follow smooth vector field
- Speed decreases with higher focus (calm = slow motion)
- Color transitions smoothly between states
- 60 FPS animation with `requestAnimationFrame`

**Particle Count:** Dynamically scaled based on canvas size
**DPR Support:** Handles high-density displays (Retina, etc.)

## ⌨️ Keyboard Shortcuts

- Type or move mouse to **auto-start** tracking
- All controls accessible via mouse/keyboard

## 🎯 Use Cases

- **Deep Work Sessions** - Visual feedback on concentration
- **Writing & Coding** - Monitor typing flow
- **Meditation Timer** - Track stillness
- **Productivity Research** - Study focus patterns
- **Ambient Display** - Peaceful background visual

## 🛠️ Development

### Tech Stack

- **TypeScript** - Type-safe code
- **Vite** - Lightning-fast dev server & build
- **Canvas API** - Hardware-accelerated graphics
- **Vanilla JS** - No framework dependencies (minimal bundle size)

### Commands

```bash
npm run dev         # Start dev server
npm run build       # Build for production
npm run preview     # Preview production build
npm run type-check  # TypeScript type checking
```

### Performance

- **Bundle size:** ~25 KB gzipped
- **First paint:** <100ms
- **Animation:** 60 FPS (adaptive on lower-end devices)
- **Memory:** <50 MB (efficient particle pooling)

## 🎨 Customization

Edit these files to customize behavior:

**Colors** (`src/visual/colors.ts`):
```typescript
export const DAY_THEME = {
  background: '#f8f9fa',
  primary: '#6CA6D9',
  // ...customize colors
};
```

**Focus Formula** (`src/focus/focusIndex.ts`):
```typescript
const focus = 
  0.4 * typingStability +
  0.35 * dwell -
  0.15 * mouseJitter -
  0.10 * idle;
```

**Visual Settings** (`src/visual/scene.ts`):
- Particle count
- Flow field parameters
- Animation speed

## 📝 License

MIT License - feel free to use, modify, and distribute!

## 🙏 Acknowledgments

Inspired by:
- Flow state research
- Ambient computing
- Meditative UX design

## 📧 Support

Questions or feedback? Open an issue or start a discussion!

---

**Remember:** All metrics are computed locally. No data is stored or transmitted. Your focus is your business. 🧘✨

