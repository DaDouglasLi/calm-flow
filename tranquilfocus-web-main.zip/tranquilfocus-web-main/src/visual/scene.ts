/**
 * Tranquil canvas scene with flow field animation
 * Creates a meditative visual that responds to focus index
 */

import { getFocusColor, type FocusColor } from './colors';
import { lerp, clamp } from '../utils/math';

// Simple Perlin noise implementation
class PerlinNoise {
  private permutation: number[];

  constructor(seed: number = Math.random()) {
    // Initialize permutation table
    this.permutation = [];
    for (let i = 0; i < 256; i++) {
      this.permutation[i] = i;
    }
    
    // Shuffle using seed
    for (let i = 255; i > 0; i--) {
      const j = Math.floor((seed * (i + 1))) % (i + 1);
      [this.permutation[i], this.permutation[j]] = [this.permutation[j], this.permutation[i]];
      seed = (seed * 16807) % 2147483647;
    }
    
    // Duplicate for overflow
    this.permutation = [...this.permutation, ...this.permutation];
  }

  private fade(t: number): number {
    return t * t * t * (t * (t * 6 - 15) + 10);
  }

  private grad(hash: number, x: number, y: number): number {
    const h = hash & 3;
    const u = h < 2 ? x : y;
    const v = h < 2 ? y : x;
    return ((h & 1) === 0 ? u : -u) + ((h & 2) === 0 ? v : -v);
  }

  noise(x: number, y: number): number {
    const X = Math.floor(x) & 255;
    const Y = Math.floor(y) & 255;
    
    x -= Math.floor(x);
    y -= Math.floor(y);
    
    const u = this.fade(x);
    const v = this.fade(y);
    
    const a = this.permutation[X] + Y;
    const aa = this.permutation[a];
    const ab = this.permutation[a + 1];
    const b = this.permutation[X + 1] + Y;
    const ba = this.permutation[b];
    const bb = this.permutation[b + 1];
    
    return lerp(
      lerp(this.grad(this.permutation[aa], x, y), this.grad(this.permutation[ba], x - 1, y), u),
      lerp(this.grad(this.permutation[ab], x, y - 1), this.grad(this.permutation[bb], x - 1, y - 1), u),
      v
    );
  }
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
}

export class TranquilScene {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private noise: PerlinNoise;
  private particles: Particle[] = [];
  private time = 0;
  private animationId: number | null = null;
  private focusIndex = 0;
  private isDayMode = true;
  private intensity = 0.7;
  private currentColor: FocusColor;
  private targetColor: FocusColor;
  private colorTransition = 0;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false })!;
    this.noise = new PerlinNoise();
    
    // Initialize colors
    this.currentColor = getFocusColor(0, this.isDayMode);
    this.targetColor = this.currentColor;
    
    // Initialize particles
    this.initParticles();
    
    // Handle resize
    this.resize();
    window.addEventListener('resize', () => this.resize());
  }

  private resize(): void {
    const dpr = window.devicePixelRatio || 1;
    const rect = this.canvas.getBoundingClientRect();
    
    this.canvas.width = rect.width * dpr;
    this.canvas.height = rect.height * dpr;
    
    this.ctx.scale(dpr, dpr);
    
    // Reinitialize particles on resize
    this.initParticles();
  }

  private initParticles(): void {
    const rect = this.canvas.getBoundingClientRect();
    const particleCount = Math.floor((rect.width * rect.height) / 8000);
    
    this.particles = [];
    for (let i = 0; i < particleCount; i++) {
      this.particles.push(this.createParticle());
    }
  }

  private createParticle(): Particle {
    const rect = this.canvas.getBoundingClientRect();
    return {
      x: Math.random() * rect.width,
      y: Math.random() * rect.height,
      vx: 0,
      vy: 0,
      life: Math.random() * 100,
      maxLife: 100 + Math.random() * 100
    };
  }

  private updateParticle(p: Particle): void {
    const rect = this.canvas.getBoundingClientRect();
    
    // Sample flow field
    const noiseScale = 0.003;
    const timeScale = this.time * 0.0001 * (1 - this.focusIndex * 0.5);
    const angle = this.noise.noise(p.x * noiseScale, p.y * noiseScale + timeScale) * Math.PI * 2;
    
    // Flow speed based on focus (high focus = slow, calm movement)
    const speed = lerp(1.2, 0.3, this.focusIndex) * this.intensity;
    
    p.vx = Math.cos(angle) * speed;
    p.vy = Math.sin(angle) * speed;
    
    p.x += p.vx;
    p.y += p.vy;
    
    // Wrap around edges
    if (p.x < 0) p.x = rect.width;
    if (p.x > rect.width) p.x = 0;
    if (p.y < 0) p.y = rect.height;
    if (p.y > rect.height) p.y = 0;
    
    // Update life
    p.life++;
    if (p.life > p.maxLife) {
      p.life = 0;
      p.maxLife = 100 + Math.random() * 100;
    }
  }

  private drawParticle(p: Particle): void {
    const lifeRatio = p.life / p.maxLife;
    const opacity = Math.sin(lifeRatio * Math.PI) * 0.4 * this.intensity;
    
    // Smoothly transition between colors
    const color = this.lerpColor(this.currentColor, this.targetColor, this.colorTransition);
    
    this.ctx.fillStyle = `rgba(${Math.round(color.r)}, ${Math.round(color.g)}, ${Math.round(color.b)}, ${opacity})`;
    this.ctx.beginPath();
    this.ctx.arc(p.x, p.y, 2, 0, Math.PI * 2);
    this.ctx.fill();
  }

  private lerpColor(c1: FocusColor, c2: FocusColor, t: number): FocusColor {
    return {
      r: lerp(c1.r, c2.r, t),
      g: lerp(c1.g, c2.g, t),
      b: lerp(c1.b, c2.b, t),
      label: t < 0.5 ? c1.label : c2.label
    };
  }

  private render(): void {
    const rect = this.canvas.getBoundingClientRect();
    
    // Update target color based on focus
    const newTargetColor = getFocusColor(this.focusIndex, this.isDayMode);
    if (newTargetColor.label !== this.targetColor.label) {
      this.currentColor = this.targetColor;
      this.targetColor = newTargetColor;
      this.colorTransition = 0;
    }
    
    // Smooth color transition
    if (this.colorTransition < 1) {
      this.colorTransition = Math.min(1, this.colorTransition + 0.02);
    }
    
    // Background with gradient
    const bgColor = this.isDayMode ? '#f8f9fa' : '#1a202c';
    const gradientColor = this.lerpColor(this.currentColor, this.targetColor, this.colorTransition);
    const gradient = this.ctx.createRadialGradient(
      rect.width / 2, rect.height / 2, 0,
      rect.width / 2, rect.height / 2, rect.width / 2
    );
    gradient.addColorStop(0, bgColor);
    gradient.addColorStop(1, `rgba(${Math.round(gradientColor.r)}, ${Math.round(gradientColor.g)}, ${Math.round(gradientColor.b)}, 0.05)`);
    
    this.ctx.fillStyle = gradient;
    this.ctx.fillRect(0, 0, rect.width, rect.height);
    
    // Update and draw particles
    for (const particle of this.particles) {
      this.updateParticle(particle);
      this.drawParticle(particle);
    }
    
    this.time++;
  }

  /**
   * Start the animation loop
   */
  start(): void {
    if (this.animationId !== null) return;
    
    const animate = () => {
      this.render();
      this.animationId = requestAnimationFrame(animate);
    };
    
    animate();
  }

  /**
   * Stop the animation loop
   */
  stop(): void {
    if (this.animationId !== null) {
      cancelAnimationFrame(this.animationId);
      this.animationId = null;
    }
  }

  /**
   * Update focus index (0-1)
   */
  setFocusIndex(value: number): void {
    this.focusIndex = clamp(value, 0, 1);
  }

  /**
   * Set day/night mode
   */
  setDayMode(isDayMode: boolean): void {
    this.isDayMode = isDayMode;
    this.currentColor = getFocusColor(this.focusIndex, isDayMode);
    this.targetColor = getFocusColor(this.focusIndex, isDayMode);
  }

  /**
   * Set visual intensity (0-1)
   */
  setIntensity(value: number): void {
    this.intensity = clamp(value, 0, 1);
  }

  /**
   * Get current focus color label
   */
  getColorLabel(): string {
    return this.targetColor.label;
  }

  /**
   * Cleanup
   */
  destroy(): void {
    this.stop();
    window.removeEventListener('resize', () => this.resize());
  }
}

