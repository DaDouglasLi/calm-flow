# Assist Mode Documentation - TranquilFocus

## Overview

Assist Mode provides intelligent, gentle interventions to help users maintain focus without being intrusive. It monitors focus levels continuously and responds with contextual nudges and positive reinforcement.

**Branch:** `feat/assist-actions`  
**Philosophy:** Gentle assistance, not interruption

---

## Features

### 1. Low Focus Nudges

**Trigger Conditions:**
- Focus drops below **0.35** (configurable)
- Stays below threshold **continuously for 120 seconds** (2 minutes)
- Mode is set to "Assist" (not "Tranquil")

**Behavior:**
```javascript
if (focus < 0.35 for 120s continuously) {
  Send toast: "Take a 60s micro-break?"
}
```

**Throttling:**
- Maximum **one nudge every 15 minutes**
- Prevents notification fatigue
- Logged when throttled with remaining cooldown time

**Visual:**
- Bottom-right toast notification
- Orange gradient background
- Auto-fades after 5 seconds
- Non-blocking, non-intrusive

### 2. High Focus Streak Celebrations

**Trigger Conditions:**
- Focus reaches **≥ 0.7** (high focus)
- Stays above threshold **continuously for 5 minutes**
- Mode is set to "Assist"

**Behavior:**
```javascript
if (focus >= 0.7 for 5min continuously) {
  Send toast: "Great streak! 🎯"
  Play optional chime
}
```

**Throttling:**
- Maximum **one celebration every 15 minutes**
- Prevents over-celebration
- Maintains specialness of achievement

**Visual:**
- Bottom-right toast notification
- Blue-green gradient background
- Auto-fades after 4 seconds
- Optional success chime (Web Audio API)

### 3. Respect for Tranquil Mode

**Behavior:**
```javascript
if (mode === 'tranquil') {
  // No nudges
  // No celebrations
  // Silent monitoring only
}
```

**Purpose:**
- Users who prefer self-regulation
- No interruptions whatsoever
- Pure visual feedback via overlay

---

## Toast Notifications

### Design

**Position:** Bottom-right corner (24px from edges)  
**Size:** Max 300px width, auto height  
**Animation:** Slide up + fade in (300ms)  
**Duration:** 4-5 seconds, then auto-fade

### Types

#### Nudge Toast

```css
Background: Orange gradient (rgba(216, 155, 107) → rgba(255, 138, 101))
Border: Left white accent (3px)
Text: White, 14px
Duration: 5 seconds
```

**Example:**
```
┌────────────────────────┐
│ Take a 60s micro-break?│
└────────────────────────┘
```

#### Celebration Toast

```css
Background: Blue-green gradient (rgba(108, 166, 217) → rgba(107, 207, 127))
Border: Left white accent (3px)
Text: White, 14px
Duration: 4 seconds
```

**Example:**
```
┌────────────────────┐
│ Great streak! 🎯   │
└────────────────────┘
```

### Accessibility

- **Reduced Motion**: No slide animation, just fade
- **High Contrast**: White border added
- **Print**: Hidden
- **Screen Readers**: Text content accessible
- **Non-blocking**: `pointer-events: none`

---

## Success Chime

### Implementation

Uses **Web Audio API** to generate a pleasant, very quiet chime:

```javascript
// C major chord (C5, E5, G5)
frequencies = [523.25, 659.25, 783.99]

// Settings
volume = 0.03 (3% - very quiet)
duration = 0.3 seconds
fadeOut = 0.15 seconds
oscillator = 'sine' wave

// Effect: Arpeggio (notes slightly staggered)
```

### Characteristics

- **Volume:** 3% (barely audible, not jarring)
- **Tone:** Pleasant C major chord
- **Duration:** 300ms (brief, non-disruptive)
- **Fade:** Smooth exponential fade-out
- **Style:** Arpeggio effect (notes overlap slightly)

### Fallback

If Web Audio API fails:
- Error logged to console
- Toast still appears
- No audio, visual feedback only

---

## Throttling System

### Purpose

Prevent notification fatigue while maintaining effectiveness.

### Cooldown Periods

```javascript
NUDGE_COOLDOWN = 15 minutes
STREAK_COOLDOWN = 15 minutes
```

### Logic

```javascript
function canSendNudge(now) {
  const elapsed = now - lastNudgeTime;
  
  if (elapsed >= NUDGE_COOLDOWN_MS) {
    return true; // Can send
  } else {
    const remainingMin = ceil((COOLDOWN - elapsed) / 60000);
    console.log(`Throttled. Wait ${remainingMin} more minutes.`);
    return false; // Blocked
  }
}
```

### Benefits

- **Prevents spam:** Max 4 nudges per hour
- **Maintains effectiveness:** Nudges feel meaningful
- **User-friendly:** Not annoying
- **Logged:** Debug info shows throttle state

---

## Continuous Focus Tracking

### Low Focus Timer

```
State Machine:

focus < 0.35 → Start timer (lowFocusStartTime = now)
             ↓
         Still low?
             ↓
    elapsed >= 120s?
             ↓
      Can send nudge?
             ↓
        Send nudge!
        Reset timer

focus >= 0.35 → Reset timer (lowFocusStartTime = null)
```

### High Focus Timer

```
State Machine:

focus >= 0.7 → Start timer (highFocusStartTime = now)
            ↓
        Still high?
            ↓
    elapsed >= 5min?
            ↓
     Can celebrate?
            ↓
      Celebrate!
      Reset timer

focus < 0.7 → Reset timer (highFocusStartTime = null)
```

### Edge Cases

**Middle Range (0.35 - 0.7):**
- Both timers reset
- No actions triggered
- Waiting for extreme states

**Mode Change:**
```javascript
if (mode === 'tranquil') {
  lowFocusStartTime = null;
  highFocusStartTime = null;
  // Clean slate, no pending actions
}
```

---

## Message Protocol

### NUDGE Message

**Direction:** Background → Content Scripts

```javascript
{
  type: 'NUDGE',
  text: 'Take a 60s micro-break?',
  timestamp: 1698765432100
}
```

**Handler:** `content.js`
```javascript
case 'NUDGE':
  window.TranquilFocusToast.showNudgeToast(message.text);
```

### STREAK_CELEBRATION Message

**Direction:** Background → Content Scripts

```javascript
{
  type: 'STREAK_CELEBRATION',
  text: 'Great streak! 🎯',
  playChime: true,
  timestamp: 1698765432100
}
```

**Handler:** `content.js`
```javascript
case 'STREAK_CELEBRATION':
  window.TranquilFocusToast.showCelebrationToast(
    message.text,
    message.playChime
  );
```

---

## Configuration

### Constants (background.js)

```javascript
// Thresholds
const LOW_FOCUS_THRESHOLD = 0.35;
const HIGH_FOCUS_THRESHOLD = 0.7;

// Durations
const LOW_FOCUS_DURATION_MS = 120 * 1000;  // 2 minutes
const HIGH_FOCUS_DURATION_MS = 5 * 60 * 1000; // 5 minutes

// Throttling
const NUDGE_COOLDOWN_MS = 15 * 60 * 1000;  // 15 minutes
const STREAK_COOLDOWN_MS = 15 * 60 * 1000; // 15 minutes
```

### Customization

To adjust behavior, modify these constants:

**Make nudges more frequent:**
```javascript
const NUDGE_COOLDOWN_MS = 10 * 60 * 1000; // 10 min
```

**Lower streak threshold:**
```javascript
const HIGH_FOCUS_THRESHOLD = 0.6; // Easier to achieve
```

**Faster nudge trigger:**
```javascript
const LOW_FOCUS_DURATION_MS = 60 * 1000; // 1 minute
```

---

## User Experience Flow

### Scenario 1: Distracted User

```
09:00 - User starts working
09:05 - Focus drops to 0.30
09:07 - Still at 0.28 (2 min elapsed)
        → Toast: "Take a 60s micro-break?"
09:08 - User takes break
09:10 - Returns, focus → 0.65
```

### Scenario 2: Focused Streak

```
10:00 - User starts deep work
10:02 - Focus reaches 0.75
10:07 - Still at 0.78 (5 min elapsed)
        → Toast: "Great streak! 🎯"
        → Chime plays
10:08 - User feels validated
10:15 - Focus maintained at 0.80
        → No new celebration (throttled)
```

### Scenario 3: Tranquil Mode

```
11:00 - User switches to Tranquil Mode
11:05 - Focus drops to 0.25
11:07 - Still at 0.22 (2 min elapsed)
        → No nudge (Tranquil Mode active)
11:10 - Focus self-regulates to 0.50
```

---

## Analytics & Debugging

### Console Logs

**Low Focus Detected:**
```
Low focus detected, starting timer
```

**High Focus Detected:**
```
High focus detected, tracking streak
```

**Throttled:**
```
Nudge throttled. Wait 12 more minutes.
```

**Sent:**
```
Sending nudge: Take a 60s micro-break?
Celebrating focus streak!
```

**Recovery:**
```
Focus recovered from low state
Focus dropped from high state
```

---

## Privacy & Data

**What's Tracked:**
- Focus level (number)
- Timestamps of state changes
- Throttle timestamps

**What's NOT Tracked:**
- Page content
- Keystrokes
- URLs
- User behavior

**Storage:**
- All data in memory only
- No persistent logs
- Throttle state resets on reload

---

## Future Enhancements

- [ ] Customizable nudge messages
- [ ] Multiple chime options
- [ ] User-configurable thresholds
- [ ] Nudge history/statistics
- [ ] Smart scheduling (time of day)
- [ ] Progressive nudge intensity
- [ ] Integration with break timer
- [ ] Machine learning for personalization

---

**Last Updated:** 2024  
**Branch:** feat/assist-actions  
**Version:** 0.5.0

