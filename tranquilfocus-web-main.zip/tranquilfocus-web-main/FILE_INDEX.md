# 📑 File Index - Quick Reference

Jump to any file or section quickly!

## 🚀 Getting Started

| File | Purpose | When to Use |
|------|---------|-------------|
| **🎉_START_HERE.md** | Welcome & overview | First time here |
| **QUICKSTART.md** | 60-second setup | Want to run now |
| **README.md** | Full documentation | Need complete guide |

## 📚 Documentation

| File | Content | Audience |
|------|---------|----------|
| **README.md** | Features, usage, API, customization | Users & developers |
| **QUICKSTART.md** | Minimal getting started | Beginners |
| **DEPLOYMENT.md** | Deploy to 10+ platforms | Ready to deploy |
| **MIGRATION_GUIDE.md** | Extension → Web transformation | Curious developers |
| **PROJECT_SUMMARY.md** | Architecture, stats, overview | Technical overview |
| **STRUCTURE.txt** | File tree & statistics | Project navigation |
| **FILE_INDEX.md** | This file | Quick reference |

## 💻 Source Code

### Core Application

| File | Lines | Purpose |
|------|-------|---------|
| **src/main.ts** | ~20 | Application bootstrap & entry point |
| **src/app.ts** | ~100 | Main orchestrator, integrates all modules |
| **src/style.css** | ~400 | Global styles, responsive design |

### Focus Logic

| File | Lines | Purpose |
|------|-------|---------|
| **src/focus/sensors.ts** | ~150 | Keyboard/mouse event tracking |
| **src/focus/focusIndex.ts** | ~150 | Focus calculation & smoothing algorithm |

### Visual Components

| File | Lines | Purpose |
|------|-------|---------|
| **src/visual/scene.ts** | ~250 | Canvas animation, Perlin noise, particles |
| **src/visual/colors.ts** | ~100 | Color palettes, theme management |

### UI Components

| File | Lines | Purpose |
|------|-------|---------|
| **src/ui/controls.ts** | ~200 | Control panel (buttons, sliders, display) |
| **src/ui/overlay.ts** | ~40 | Minimal status band overlay |

### Utilities

| File | Lines | Purpose |
|------|-------|---------|
| **src/utils/math.ts** | ~80 | Math helpers (lerp, clamp, variance, etc.) |

## ⚙️ Configuration

| File | Purpose |
|------|---------|
| **package.json** | Dependencies, scripts, metadata |
| **tsconfig.json** | TypeScript compiler settings |
| **vite.config.js** | Vite build configuration |
| **.gitignore** | Git ignore patterns |

## 🎨 Assets

| File | Purpose |
|------|---------|
| **assets/logo.svg** | TranquilFocus logo (concentric ripples) |
| **assets/README.md** | Asset documentation |
| **public/favicon.svg** | Site favicon (logo copy) |

## 🌐 HTML

| File | Purpose |
|------|---------|
| **index.html** | HTML entry point, app shell |

## 📊 Quick Stats

```
Total Files:          ~25
TypeScript Modules:    9
Documentation:         7
Config Files:          4
Assets:                3
CSS Files:             1
HTML Files:            1

Lines of Code:      ~1,800 (src/)
Lines of Docs:      ~3,000 (md files)
Lines of CSS:         ~400
Total Lines:        ~5,200+
```

## 🔍 Find What You Need

### Want to...

**Run the app?**
→ QUICKSTART.md → `npm install && npm run dev`

**Deploy the app?**
→ DEPLOYMENT.md → Choose platform → Follow guide

**Understand architecture?**
→ PROJECT_SUMMARY.md → "How It Works" section

**Customize colors?**
→ src/visual/colors.ts → Edit DAY_THEME / NIGHT_THEME

**Change focus formula?**
→ src/focus/focusIndex.ts → Edit calculateFocusIndex()

**Modify animation?**
→ src/visual/scene.ts → Edit particle/flow parameters

**Add new UI controls?**
→ src/ui/controls.ts → Add to render() method

**Fix TypeScript errors?**
→ Run `npm run type-check` → Check console

**Understand migration?**
→ MIGRATION_GUIDE.md → See transformation details

**See file structure?**
→ STRUCTURE.txt → Complete tree view

## 🎯 Common Tasks

### Development

```bash
# Install
npm install

# Run dev server
npm run dev

# Type check
npm run type-check

# Build
npm run build

# Preview build
npm run preview
```

### File Editing

```bash
# Change colors
Edit: src/visual/colors.ts

# Adjust focus algorithm
Edit: src/focus/focusIndex.ts

# Modify UI layout
Edit: src/style.css

# Update controls
Edit: src/ui/controls.ts

# Tweak animation
Edit: src/visual/scene.ts
```

## 📖 Reading Order

### For Users

1. 🎉_START_HERE.md (welcome)
2. QUICKSTART.md (get running)
3. README.md (full features)
4. DEPLOYMENT.md (go live)

### For Developers

1. PROJECT_SUMMARY.md (architecture)
2. STRUCTURE.txt (file layout)
3. src/main.ts → src/app.ts (entry points)
4. src/focus/* (core logic)
5. src/visual/* (rendering)
6. src/ui/* (interface)

### For Curious

1. MIGRATION_GUIDE.md (transformation story)
2. src/ (explore code)
3. Customize & experiment!

## 🗺️ Module Map

```
main.ts
  └─ app.ts (orchestrator)
      ├─ focus/sensors.ts (input tracking)
      ├─ focus/focusIndex.ts (calculation)
      │   └─ utils/math.ts
      ├─ visual/scene.ts (animation)
      │   ├─ visual/colors.ts
      │   └─ utils/math.ts
      ├─ ui/controls.ts (control panel)
      └─ ui/overlay.ts (status band)
```

## 🎨 Asset Map

```
assets/
  ├─ logo.svg (source logo)
  └─ README.md (asset docs)

public/
  └─ favicon.svg (deployment favicon)

(Add your own screenshots/demos to assets/)
```

## 📝 Documentation Map

```
Root Level Docs:
├─ 🎉_START_HERE.md      ← Start here!
├─ QUICKSTART.md         ← Fast setup
├─ README.md             ← Main docs
├─ DEPLOYMENT.md         ← Deploy guide
├─ MIGRATION_GUIDE.md    ← Transform story
├─ PROJECT_SUMMARY.md    ← Tech overview
├─ STRUCTURE.txt         ← File tree
└─ FILE_INDEX.md         ← This file

In-Folder Docs:
└─ assets/README.md      ← Asset guide
```

## 🔗 External Links

- **Vite Docs:** https://vitejs.dev/
- **TypeScript:** https://www.typescriptlang.org/
- **Canvas API:** https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API
- **Vercel:** https://vercel.com/
- **Netlify:** https://www.netlify.com/

---

**Need something specific?** Use Ctrl+F (Cmd+F) to search this index!

