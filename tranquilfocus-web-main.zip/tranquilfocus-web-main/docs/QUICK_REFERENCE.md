# TranquilFocus Quick Reference

## Focus Index Formula (v2.0)

```
Focus = 0.4 × typingStability + 0.35 × dwell - 0.15 × mouseJitter - 0.10 × idle
```

## Input Normalization

| Input | Formula | Range | Cap |
|-------|---------|-------|-----|
| `typingStability` | `1 - variance(IKI) / 400` | 0..1 | 400ms² |
| `mouseJitter` | `mouseHz / 10` | 0..1 | 10 Hz |
| `dwell` | `dwellSec / 180` | 0..1 | 180s (3min) |
| `idle` | `(now - lastInputAt) / 5000` | 0..1 | 5000ms |

## Weights

| Factor | Weight | Direction |
|--------|--------|-----------|
| Typing Stability | 40% | ➕ Positive |
| Dwell Time | 35% | ➕ Positive |
| Mouse Jitter | 15% | ➖ Negative |
| Idle Time | 10% | ➖ Negative |

## Smoothing

- **Attack:** 300ms (fast rise)
- **Release:** 1500ms (slow fall)

```
α = 1 - e^(-Δt/τ)
smoothed = prev + α(new - prev)
```

## Key Files

- **Algorithm:** `src/background/focus.js` + `focus.ts`
- **Sensors:** `src/content/sensors.js` + `sensors.ts`
- **Integration:** `background.js` (SENSOR_TICK handler)
- **Docs:** `docs/FOCUS_ALGORITHM.md`

## Update Cycle

```
Every 1 second:
1. Content script captures sensor data
2. Sends SENSOR_TICK to background
3. Background calculates focus index
4. Broadcasts FOCUS_UPDATE to all tabs
5. UI updates overlay display
```

## Typical Focus Scores

| Scenario | Score | Characteristics |
|----------|-------|-----------------|
| Deep coding | 0.6-0.9 | Steady typing, long dwell, minimal mouse |
| Reading | 0.2-0.5 | No typing, moderate dwell, some idle |
| Browsing | 0.0-0.3 | Erratic input, short dwell, high mouse |
| Distracted | 0.0-0.2 | Tab switching, high idle, high jitter |

## Tuning Parameters

### In `src/background/focus.js`:

```javascript
// Normalization caps
const MAX_IKI_VARIANCE = 400;    // ms²
const MAX_MOUSE_HZ = 10;         // Hz
const MAX_DWELL_SEC = 180;       // seconds
const MAX_IDLE_MS = 5000;        // milliseconds

// Weights
0.4  // typingStability weight
0.35 // dwell weight
0.15 // mouseJitter weight (negative)
0.10 // idle weight (negative)

// Smoothing
const ATTACK_TIME = 300;   // ms
const RELEASE_TIME = 1500; // ms
```

## Debug Console Output

```javascript
Focus calculation: {
  typingStability: 0.845,
  mouseJitter: 0.230,
  dwell: 0.890,
  idle: 0.120,
  rawFocus: 0.623,
  smoothedFocus: 0.598
}
```

## Common Issues

**Focus always 0:**
- Check if page is visible (`visible: true`)
- Verify sensor data is being sent (check console for "Sensor tick")
- Ensure background script loaded focus module

**Focus jumps erratically:**
- Attack/release smoothing should prevent this
- Check if smoother is initialized (`focusSmoother !== null`)

**No typing stability:**
- Need at least 2 keystrokes (`ikiMsArray.length >= 2`)
- Variance calculation requires data

---

**Version:** 2.0 (feat/focus-core)  
**Last Updated:** 2024

