/**
 * Color palettes and theme management
 */

export interface ColorScheme {
  background: string;
  primary: string;
  secondary: string;
  accent: string;
  text: string;
  textMuted: string;
}

export interface FocusColor {
  r: number;
  g: number;
  b: number;
  label: string;
}

/**
 * Day theme colors
 */
export const DAY_THEME: ColorScheme = {
  background: '#f8f9fa',
  primary: '#6CA6D9',      // Calm blue
  secondary: '#8E8CD8',    // Violet
  accent: '#D89B6B',       // Soft orange
  text: '#2d3748',
  textMuted: '#718096'
};

/**
 * Night theme colors
 */
export const NIGHT_THEME: ColorScheme = {
  background: '#1a202c',
  primary: '#4A90C8',      // Deeper blue
  secondary: '#7C7AC6',    // Deeper violet
  accent: '#C68952',       // Deeper orange
  text: '#e2e8f0',
  textMuted: '#a0aec0'
};

/**
 * Get color based on focus index
 * High focus (>0.7) = Blue (tranquil)
 * Medium focus (0.4-0.7) = Violet (balanced)
 * Low focus (<0.4) = Orange (scattered)
 */
export function getFocusColor(focusIndex: number, isDayMode: boolean = true): FocusColor {
  if (focusIndex >= 0.7) {
    const base = isDayMode ? { r: 108, g: 166, b: 217 } : { r: 74, g: 144, b: 200 };
    return { ...base, label: 'Tranquil' };
  } else if (focusIndex >= 0.4) {
    const base = isDayMode ? { r: 142, g: 140, b: 216 } : { r: 124, g: 122, b: 198 };
    return { ...base, label: 'Balanced' };
  } else {
    const base = isDayMode ? { r: 216, g: 155, b: 107 } : { r: 198, g: 137, b: 82 };
    return { ...base, label: 'Scattered' };
  }
}

/**
 * Convert RGB to hex color
 */
export function rgbToHex(r: number, g: number, b: number): string {
  return '#' + [r, g, b].map(x => {
    const hex = Math.round(x).toString(16);
    return hex.length === 1 ? '0' + hex : hex;
  }).join('');
}

/**
 * Parse hex color to RGB
 */
export function hexToRgb(hex: string): { r: number; g: number; b: number } | null {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : null;
}

/**
 * Interpolate between two colors
 */
export function lerpColor(
  color1: FocusColor,
  color2: FocusColor,
  t: number
): FocusColor {
  return {
    r: color1.r + (color2.r - color1.r) * t,
    g: color1.g + (color2.g - color1.g) * t,
    b: color1.b + (color2.b - color1.b) * t,
    label: t < 0.5 ? color1.label : color2.label
  };
}

